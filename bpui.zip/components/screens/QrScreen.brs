sub init()
    c = m.global.colors
    m.top.findNode("bg").color = c.bg
    m.top.findNode("title").color = c.text
    m.top.findNode("text").color = c.muted
    m.top.findNode("url").color = c.accent
end sub

sub onParams()
    p = m.top.params
    u = CreateObject("roUrlTransfer")
    m.top.findNode("qr").uri = "https://api.qrserver.com/v1/create-qr-code/?size=560x560&margin=0&data=" + u.Escape(p.url)
    title = p.title
    if title = invalid then title = tx("jworg")
    text = p.text
    if text = invalid then text = tx("jworg_qr")
    m.top.findNode("title").text = title
    m.top.findNode("text").text = text
    m.top.findNode("url").text = p.url.Replace("https://", "")
    m.top.setFocus(true)
end sub

sub onStop()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if press and key = "OK" then
        m.top.action = {type: "back"}
        return true
    end if
    return false
end function
