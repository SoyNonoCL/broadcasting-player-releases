' Conectar Google Drive (código de dispositivo).

sub init()
    c = m.global.colors
    m.top.findNode("bg").color = c.bg
    m.top.findNode("title").color = c.text
    m.top.findNode("text").color = c.muted
    m.top.findNode("url").color = c.accent
    m.top.findNode("codeBg").blendColor = c.card
    m.top.findNode("code").color = c.text
    m.top.findNode("status").color = c.muted
    m.top.findNode("title").text = tx("drive_connect")
    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/icons/replay.png"
    m.spinner.poster.width = 56
    m.spinner.poster.height = 56
end sub

sub onParams()
    m.top.setFocus(true)
    m.top.findNode("status").text = tx("loading")
    m.task = bpNode("ApiTask")
    m.task.observeField("response", "onCode")
    m.task.request = {type: "driveStart", id: "driveStart"}
    m.task.control = "RUN"
end sub

sub onCode()
    r = m.task.response
    dc = r.code
    if dc = invalid or dc.error <> invalid then
        msg = tx("drive_error")
        if dc <> invalid then print "DRIVE "; dc.error
        m.top.findNode("status").text = msg
        m.spinner.visible = false
        return
    end if
    m.top.findNode("text").text = tx("drive_code", dc.url.Replace("https://", ""))
    m.top.findNode("url").text = dc.url.Replace("https://", "")
    m.top.findNode("code").text = dc.userCode
    u = CreateObject("roUrlTransfer")
    m.top.findNode("qr").uri = "https://api.qrserver.com/v1/create-qr-code/?size=340x340&margin=0&data=" + u.Escape(dc.url)
    m.top.findNode("qrBg").visible = true
    m.top.findNode("codeBg").visible = true
    m.top.findNode("status").text = tx("drive_waiting")
    m.spinner.control = "start"
    m.wait = bpNode("ApiTask")
    m.wait.observeField("response", "onDone")
    m.wait.request = {type: "driveWait", code: dc, id: "driveWait"}
    m.wait.control = "RUN"
end sub

sub onDone()
    r = m.wait.response
    m.spinner.control = "stop"
    m.spinner.visible = false
    if r.connected = true then
        msg = tx("drive_synced")
        if r.sync <> invalid and r.sync.restored <> invalid and r.sync.restored > 0 then msg = tx("drive_restored", r.sync.restored)
        m.top.action = {type: "toast", text: msg}
        m.top.action = {type: "back"}
    else
        m.top.findNode("status").text = tx("drive_error")
    end if
end sub

sub onStop()
    ' la espera en segundo plano termina sola cuando vence el código
    if m.wait <> invalid then m.wait.unobserveField("response")
end sub
