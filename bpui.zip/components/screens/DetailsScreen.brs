' Ficha de un video.

sub init()
    c = m.global.colors
    m.top.findNode("bg").color = c.bg
    m.top.findNode("fadeLeft").blendColor = c.scrim
    m.top.findNode("fadeBottom").blendColor = c.scrim
    m.title = m.top.findNode("title")
    m.meta = m.top.findNode("meta")
    m.desc = m.top.findNode("desc")
    m.title.color = c.text
    m.meta.color = c.accent
    m.desc.color = c.muted
    m.hint = m.top.findNode("hint")
    m.hint.color = c.muted
    m.buttons = m.top.findNode("buttons")
    m.buttons.color = c.text
    m.buttons.focusedColor = c.focusText
    m.buttons.focusBitmapBlendColor = c.focus
    m.buttons.observeField("itemSelected", "onButton")
end sub

sub onParams()
    m.item = m.top.params.item
    it = m.item
    m.top.findNode("backdrop").uri = it.backdrop
    m.title.text = it.title
    meta = it.durationText
    if it.published <> "" then meta = meta + "   ·   " + it.published
    m.meta.text = meta
    m.desc.text = it.description
    tb = m.title.boundingRect()
    m.meta.translation = [0, tb.height + 16]
    m.desc.translation = [0, tb.height + 66]
    m.hint.text = tx("roku_fav_hint")
    buildButtons()
    m.buttons.setFocus(true)
end sub

sub buildButtons()
    p = progressGet(m.item)
    root = CreateObject("roSGNode", "ContentNode")
    m.ids = []
    if p <> invalid and p.p > 0 then
        addButton(root, "resume", "▶   " + tx("resume", fmtTime(p.p)))
        addButton(root, "restart", "     " + tx("restart"))
    else
        addButton(root, "play", "▶   " + tx("play"))
    end if
    if favIsOn(m.item) then
        addButton(root, "fav", "♥   " + tx("fav_remove"))
    else
        addButton(root, "fav", "♡   " + tx("fav_add"))
    end if
    m.buttons.content = root
end sub

sub addButton(root as object, id as string, label as string)
    n = root.createChild("ContentNode")
    n.title = "   " + label
    m.ids.push(id)
end sub

sub onButton()
    id = m.ids[m.buttons.itemSelected]
    if id = "fav" then
        m.top.action = {type: "fav", item: m.item}
        sel = m.buttons.itemFocused
        buildButtons()
        m.buttons.jumpToItem = sel
        return
    end if
    posSec = 0
    if id = "resume" then posSec = progressGet(m.item).p
    m.top.action = {type: "play", items: [m.item], index: 0, position: posSec}
end sub

sub onRefresh()
    sel = m.buttons.itemFocused
    buildButtons()
    m.buttons.jumpToItem = 0
    m.buttons.setFocus(true)
end sub

sub onStop()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "options" then
        m.top.action = {type: "fav", item: m.item}
        buildButtons()
        return true
    else if key = "play" then
        p = progressGet(m.item)
        posSec = 0
        if p <> invalid then posSec = p.p
        m.top.action = {type: "play", items: [m.item], index: 0, position: posSec}
        return true
    end if
    return false
end function
