' Buscar por palabras (que empiecen así, sin importar tildes), tema y fecha.

sub init()
    c = m.global.colors
    m.top.findNode("bg").color = c.bg
    m.top.findNode("title").color = c.text
    m.top.findNode("title").text = tx("search")
    m.hint = m.top.findNode("hint")
    m.hint.color = c.muted
    months = readJson(bpRoot() + "data/months/" + m.global.strings._ui + ".json")
    example = "2025"
    if months <> invalid then example = months.example
    m.months = months
    m.hint.text = tx("roku_search_hint", example) + Chr(10) + Chr(10) + tx("roku_fav_hint")
    m.message = m.top.findNode("message")
    m.message.color = c.muted
    m.message.text = tx("search_hint")
    m.count = m.top.findNode("count")
    m.count.color = c.muted
    m.chip = m.top.findNode("chip")
    m.top.findNode("chipBg").blendColor = c.accent
    m.top.findNode("chipText").color = "0xFFFFFFFF"
    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/icons/replay.png"
    m.spinner.poster.width = 64
    m.spinner.poster.height = 64
    m.kb = m.top.findNode("kb")
    m.kb.observeField("text", "onText")
    m.typing = m.top.findNode("typing")
    m.typing.observeField("fire", "doSearch")
    m.rl = m.top.findNode("rows")
    m.rl.itemComponentName = bpNs() + "CardItem"
    m.rl.rowLabelColor = c.text
    m.rl.rowLabelFont = "font:SmallBoldSystemFont"
    m.rl.focusBitmapBlendColor = c.focus
    m.rl.visible = false
    m.rl.observeField("rowItemSelected", "onSelected")
    m.map = []
    m.seq = 0
    m.firstSearch = true
end sub

sub onParams()
    m.kb.setFocus(true)
end sub

sub onText()
    m.typing.control = "stop"
    m.typing.control = "start"
end sub

sub doSearch()
    q = m.kb.text.Trim()
    if q = m.lastQuery then return
    m.lastQuery = q
    if Len(q) < 2 then
        m.rl.visible = false
        m.chip.visible = false
        m.count.text = ""
        m.message.text = tx("search_hint")
        m.message.visible = true
        return
    end if
    m.seq = m.seq + 1
    if m.firstSearch then m.message.text = tx("search_preparing") else m.message.text = ""
    m.message.visible = m.firstSearch
    m.spinner.visible = true
    m.spinner.control = "start"
    t = bpNode("ApiTask")
    t.observeField("response", "onResults")
    t.request = {type: "search", lang: m.global.lang, q: q, id: "s" + m.seq.toStr()}
    t.control = "RUN"
    m.task = t
end sub

sub onResults(e as object)
    r = e.getData()
    if r.id <> "s" + m.seq.toStr() then return
    m.firstSearch = false
    m.spinner.visible = false
    m.spinner.control = "stop"
    s = r.search
    ' fecha escrita ("enero 2025", "2024")
    if s.typedYear <> invalid and s.typedYear > 0 then
        label = ""
        if s.typedMonth > 0 and m.months <> invalid then label = label + m.months.display[s.typedMonth - 1] + " "
        label = label + s.typedYear.toStr()
        ct = m.top.findNode("chipText")
        ct.text = label
        w = ct.boundingRect().width + 48
        m.top.findNode("chipBg").width = w
        m.chip.visible = true
    else
        m.chip.visible = false
    end if
    rows = []
    if s.categories.count() > 0 then rows.push({id: "c", title: tx("categories"), items: s.categories, size: [310, 240]})
    if s.results.count() > 0 then rows.push({id: "r", title: tx("search_results"), grid: true, perRow: 3, items: s.results, size: [320, 250]})
    if s.total > 0 then m.count.text = plural("results_count", s.total) else m.count.text = ""
    if rows.count() = 0 then
        m.rl.visible = false
        m.message.text = tx("no_results")
        m.message.visible = true
        return
    end if
    m.message.visible = false
    built = buildRows(rows, 3, 3)
    m.map = built.map
    applyRows(m.rl, built)
    m.rl.visible = true
end sub

sub onSelected()
    s = m.rl.rowItemSelected
    if s = invalid or s.count() < 2 or s[0] >= m.map.count() then return
    row = m.map[s[0]]
    if s[1] >= row.count() then return
    m.top.action = {type: "open", item: row[s[1]], list: row}
end sub

sub onRefresh()
    if m.rl.visible then m.rl.setFocus(true) else m.kb.setFocus(true)
end sub

sub onStop()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "right" and m.kb.isInFocusChain() and m.rl.visible then
        m.rl.setFocus(true)
        return true
    else if key = "left" and m.rl.isInFocusChain() then
        m.kb.setFocus(true)
        return true
    else if key = "options" and m.rl.isInFocusChain() then
        f = m.rl.rowItemFocused
        if f <> invalid and f.count() = 2 and f[0] < m.map.count() and f[1] < m.map[f[0]].count() then
            m.top.action = {type: "fav", item: m.map[f[0]][f[1]]}
        end if
        return true
    end if
    return false
end function
