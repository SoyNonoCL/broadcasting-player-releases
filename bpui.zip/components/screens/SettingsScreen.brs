' Ajustes.

sub init()
    c = m.global.colors
    m.c = c
    m.top.findNode("bg").color = c.bg
    m.top.findNode("title").color = c.text
    m.top.findNode("title").text = tx("settings")
    m.top.findNode("panelBg").color = c.surface
    m.top.findNode("panelTitle").color = c.text
    m.about = m.top.findNode("about")
    m.about.color = c.muted
    m.list = m.top.findNode("list")
    m.choices = m.top.findNode("choices")
    for each l in [m.list, m.choices]
        l.color = c.text
        l.focusedColor = c.focusText
        l.focusBitmapBlendColor = c.focus
    end for
    m.list.observeField("itemSelected", "onItem")
    m.choices.observeField("itemSelected", "onChoice")
    m.panel = m.top.findNode("panel")
    m.uiCodes = ["S", "E", "T", "U", "F", "X", "I", "O", "P", "K", "M", "H", "B", "G", "TK", "A", "IN", "TG", "VT", "J", "KO", "CHS", "CH", "SI", "HI", "SW", "Z", "N", "D", "FI"]
end sub

sub onParams()
    m.uiVersion = m.top.params.uiVersion
    if m.uiVersion = invalid then m.uiVersion = 0
    ai = CreateObject("roAppInfo")
    m.about.text = tx("version", ai.GetVersion() + " · UI " + m.uiVersion.toStr()) + "   ·   " + tx("about")
    build()
    m.list.setFocus(true)
end sub

function langName(code as string) as string
    info = languageInfo(code)
    if info = invalid then return code
    return info[2]
end function

sub build()
    sel = m.list.itemFocused
    m.ids = []
    root = CreateObject("roSGNode", "ContentNode")
    add(root, "lang", tx("settings_language", langName(m.global.lang)))
    ov = prefGet("ui_lang", "")
    uiLabel = tx("ui_language_auto")
    if ov <> "" then uiLabel = langName(ov)
    add(root, "ui", tx("ui_language_title") + ":  " + uiLabel)
    add(root, "quality", tx("settings_quality", prefGet("quality", "1080") + "p"))
    subs = tx("off")
    if prefGet("subs", "0") = "1" then subs = tx("on")
    add(root, "subs", tx("settings_subtitles", subs))
    th = tx("theme_night")
    if prefGet("theme", "night") = "day" then th = tx("theme_day")
    add(root, "theme", tx("theme_title") + ":  " + th)
    if regRead("drive", "refresh") <> invalid then
        email = regRead("drive", "email", "")
        add(root, "sync", tx("drive_sync_now") + "   (" + tx("drive_connected", email) + ")")
        add(root, "disconnect", tx("drive_disconnect"))
    else
        add(root, "drive", tx("drive_connect"))
    end if
    add(root, "update", tx("update_check"))
    m.list.content = root
    if sel > 0 and sel < m.ids.count() then m.list.jumpToItem = sel
end sub

sub add(root as object, id as string, label as string)
    n = root.createChild("ContentNode")
    n.title = "   " + label
    m.ids.push(id)
end sub

sub onItem()
    id = m.ids[m.list.itemSelected]
    if id = "lang" then
        m.top.action = {type: "screen", name: "LanguageScreen", params: {}}
    else if id = "ui" then
        opts = [{v: "", t: tx("ui_language_auto")}]
        for each u in m.uiCodes
            opts.push({v: u, t: langName(u)})
        end for
        openChoices("ui", tx("ui_language_title"), opts, prefGet("ui_lang", ""))
    else if id = "quality" then
        opts = []
        for each q in ["1080", "720", "480", "360", "240"]
            opts.push({v: q, t: q + "p"})
        end for
        openChoices("quality", tx("quality_title"), opts, prefGet("quality", "1080"))
    else if id = "subs" then
        if prefGet("subs", "0") = "1" then prefSet("subs", "0") else prefSet("subs", "1")
        build()
    else if id = "theme" then
        openChoices("theme", tx("theme_title"), [{v: "night", t: tx("theme_night")}, {v: "day", t: tx("theme_day")}], prefGet("theme", "night"))
    else if id = "drive" then
        m.top.action = {type: "screen", name: "DriveScreen", params: {}}
    else if id = "sync" then
        m.top.action = {type: "toast", text: tx("loading")}
        runTask({type: "driveSync", id: "sync"}, "onSynced")
    else if id = "disconnect" then
        sec = CreateObject("roRegistrySection", "drive")
        for each k in sec.GetKeyList()
            sec.Delete(k)
        end for
        sec.Flush()
        build()
    else if id = "update" then
        runTask({type: "version", id: "version"}, "onVersion")
    end if
end sub

sub runTask(req as object, cb as string)
    m.task = bpNode("ApiTask")
    m.task.observeField("response", cb)
    m.task.request = req
    m.task.control = "RUN"
end sub

sub onSynced(e as object)
    r = e.getData()
    if r.sync <> invalid and r.sync.ok = true then
        if r.sync.restored <> invalid and r.sync.restored > 0 then
            m.top.action = {type: "toast", text: tx("drive_restored", r.sync.restored)}
        else
            m.top.action = {type: "toast", text: tx("drive_synced")}
        end if
    else
        m.top.action = {type: "toast", text: tx("drive_error")}
    end if
end sub

sub onVersion(e as object)
    v = e.getData().version
    if v = invalid then
        m.top.action = {type: "toast", text: tx("error_loading")}
        return
    end if
    newer = false
    if v.roku <> invalid and v.roku.ui <> invalid and v.roku.ui.version <> invalid then newer = v.roku.ui.version > m.uiVersion
    if newer then
        m.top.action = {type: "toast", text: tx("roku_update_next")}
    else
        m.top.action = {type: "toast", text: tx("update_none")}
    end if
end sub

sub openChoices(id as string, title as string, opts as object, current as string)
    m.choiceId = id
    m.opts = opts
    m.top.findNode("panelTitle").text = title
    root = CreateObject("roSGNode", "ContentNode")
    sel = 0
    for i = 0 to opts.count() - 1
        n = root.createChild("ContentNode")
        mark = "      "
        if opts[i].v = current then
            mark = "  ✓  "
            sel = i
        end if
        n.title = mark + opts[i].t
    end for
    m.choices.content = root
    m.choices.jumpToItem = sel
    m.panel.visible = true
    m.choices.setFocus(true)
end sub

sub closeChoices()
    m.panel.visible = false
    m.list.setFocus(true)
end sub

sub onChoice()
    v = m.opts[m.choices.itemSelected].v
    id = m.choiceId
    closeChoices()
    if id = "quality" then
        prefSet("quality", v)
        build()
    else if id = "ui" then
        if v = "" then regDelete("prefs", "ui_lang") else prefSet("ui_lang", v)
        m.top.action = {type: "restart"}
    else if id = "theme" then
        if v <> prefGet("theme", "night") then
            prefSet("theme", v)
            m.top.action = {type: "restart"}
        end if
    end if
end sub

sub onRefresh()
    build()
    m.list.setFocus(true)
end sub

sub onStop()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if m.panel.visible and (key = "back" or key = "left") then
        closeChoices()
        return true
    end if
    return false
end function
