' Reproductor de audio.

sub init()
    c = m.global.colors
    m.top.findNode("bg").color = c.bg
    for each id in ["title", "state"]
        m.top.findNode(id).color = c.text
    end for
    for each id in ["count", "pos", "dur", "keys"]
        m.top.findNode(id).color = c.muted
    end for
    m.top.findNode("now").color = c.accent
    m.top.findNode("now").text = UCase(tx("now_playing"))
    m.top.findNode("barBg").color = c.card
    m.top.findNode("bar").color = c.accent
    m.top.findNode("keys").text = "▶ II  " + tx("play") + "      ◀◀ ▶▶  " + tx("prev") + " / " + tx("next") + "      ← →  10 s"
    m.audio = m.top.findNode("audio")
    m.audio.notificationInterval = 1
    m.audio.observeField("state", "onState")
    m.audio.observeField("position", "onPosition")
    m.lastSave = 0
end sub

sub onParams()
    p = m.top.params
    m.items = p.items
    m.index = p.index
    startItem(p.position)
    m.top.setFocus(true)
end sub

sub startItem(position as dynamic)
    item = m.items[m.index]
    m.item = item
    url = invalid
    for each f in item.files
        if url = invalid then url = f.url
    end for
    if url = invalid then
        m.top.action = {type: "toast", text: tx("playback_error")}
        return
    end if
    c = CreateObject("roSGNode", "ContentNode")
    c.url = url
    c.title = item.title
    c.streamFormat = "mp3"
    if LCase(Right(url, 4)) = ".m4a" or LCase(Right(url, 4)) = ".aac" then c.streamFormat = "mp4"
    if position <> invalid and position > 0 then c.PlayStart = position
    m.audio.content = c
    m.audio.control = "play"
    img = item.square
    if img = invalid or img = "" then img = item.card
    if img = invalid or img = "" then img = "pkg:/images/channel_fhd.png"
    blurImg = img
    if Instr(1, img, "pkg:") = 1 then blurImg = ""
    m.top.findNode("art").uri = img
    m.top.findNode("blur").uri = blurImg
    m.top.findNode("title").text = item.title
    if m.items.count() > 1 then
        m.top.findNode("count").text = (m.index + 1).toStr() + " / " + m.items.count().toStr()
    else
        m.top.findNode("count").text = ""
    end if
    m.top.findNode("dur").text = item.durationText
    m.top.findNode("pos").text = "0:00"
    m.top.findNode("bar").width = 0
end sub

sub onPosition()
    posSec = m.audio.position
    d = m.item.duration
    if (d = invalid or d = 0) and m.audio.duration > 0 then d = m.audio.duration
    m.top.findNode("pos").text = fmtTime(posSec)
    if d <> invalid and d > 0 then
        w = Int(900 * posSec / d)
        if w > 900 then w = 900
        m.top.findNode("bar").width = w
        m.top.findNode("dur").text = fmtTime(d)
    end if
    if Abs(Int(posSec) - m.lastSave) >= 10 then
        m.lastSave = Int(posSec)
        saveProgress()
    end if
end sub

sub saveProgress()
    d = m.item.duration
    if (d = invalid or d = 0) and m.audio.duration > 0 then d = Int(m.audio.duration)
    if d = invalid or d <= 0 then return
    progressSave(m.item, Int(m.audio.position), d)
end sub

sub onState()
    st = m.audio.state
    s = m.top.findNode("state")
    if st = "playing" then
        s.text = "▶  " + tx("now_playing")
    else if st = "paused" then
        s.text = "II"
        saveProgress()
    else if st = "buffering" then
        s.text = tx("loading")
    else if st = "finished" then
        progressSave(m.item, m.item.duration, m.item.duration)
        nextItem(1)
    else if st = "error" then
        m.top.action = {type: "toast", text: tx("playback_error")}
        s.text = ""
    end if
end sub

sub nextItem(delta as integer)
    n = m.index + delta
    if n < 0 or n >= m.items.count() then
        if delta > 0 then m.top.action = {type: "back"}
        return
    end if
    saveProgress()
    m.index = n
    m.lastSave = 0
    startItem(0)
end sub

sub onStop()
    saveProgress()
    m.audio.control = "stop"
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "play" or key = "OK" then
        if m.audio.state = "playing" then m.audio.control = "pause" else m.audio.control = "resume"
        return true
    else if key = "fastforward" or key = "down" then
        nextItem(1)
        return true
    else if key = "rewind" or key = "up" then
        if m.audio.position > 5 then
            m.audio.seek = 0
        else
            nextItem(-1)
        end if
        return true
    else if key = "right" then
        m.audio.seek = m.audio.position + 10
        return true
    else if key = "left" then
        p = m.audio.position - 10
        if p < 0 then p = 0
        m.audio.seek = p
        return true
    else if key = "options" then
        m.top.action = {type: "fav", item: m.item}
        return true
    end if
    return false
end function

' Órdenes del teléfono ("Mi TV").
sub onControl()
    c = m.top.control
    if c.cmd = "toggle" then
        if m.audio.state = "playing" then m.audio.control = "pause" else m.audio.control = "resume"
    else if c.cmd = "seek" then
        d = 0
        if c.delta <> invalid then d = c.delta.toInt()
        p = m.audio.position + d
        if p < 0 then p = 0
        m.audio.seek = p
    else if c.cmd = "next" then
        nextItem(1)
    end if
end sub
