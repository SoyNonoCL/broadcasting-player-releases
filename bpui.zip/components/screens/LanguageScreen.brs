' Idioma del contenido. Al elegirlo, los menús cambian también (si el idioma está traducido).

sub init()
    c = m.global.colors
    m.top.findNode("bg").color = c.bg
    m.top.findNode("title").color = c.text
    m.top.findNode("title").text = tx("language_title")
    m.hint = m.top.findNode("hint")
    m.hint.color = c.muted
    m.hint.text = tx("language_search")
    m.count = m.top.findNode("count")
    m.count.color = c.muted
    m.list = m.top.findNode("list")
    m.list.color = c.text
    m.list.focusedColor = c.focusText
    m.list.focusBitmapBlendColor = c.focus
    m.list.observeField("itemSelected", "onPick")
    m.kb = m.top.findNode("kb")
    m.kb.observeField("text", "applyFilter")
    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/icons/replay.png"
    m.spinner.poster.width = 64
    m.spinner.poster.height = 64
    m.spinner.control = "start"
    m.all = []
    m.shown = []
end sub

sub onParams()
    m.kb.setFocus(true)
    ' nombres de los idiomas en el idioma de los menús (por ejemplo "Alemán — Deutsch")
    m.task = bpNode("ApiTask")
    m.task.observeField("response", "onIndex")
    m.task.request = {type: "langIndex", ui: m.global.strings._ui, id: "langIndex"}
    m.task.control = "RUN"
end sub

sub onIndex()
    m.spinner.control = "stop"
    m.spinner.visible = false
    m.all = m.task.response.list
    if m.all = invalid then m.all = []
    applyFilter()
end sub

sub applyFilter()
    words = queryWords(m.kb.text)
    cur = m.global.lang
    shown = []
    first = invalid
    for each e in m.all
        ok = true
        for each w in words
            if Instr(1, e.n, " " + w) = 0 and LCase(e.c) <> w then
                ok = false
                exit for
            end if
        end for
        if ok then
            if e.c = cur and words.count() = 0 then
                first = e
            else if shown.count() < 400 then
                shown.push(e)
            end if
        end if
    end for
    if first <> invalid then shown.unshift(first)
    root = CreateObject("roSGNode", "ContentNode")
    for each e in shown
        n = root.createChild("ContentNode")
        label = e.label
        if e.c = cur then label = "✓  " + label
        if e.sign then label = label + "   ·  " + tx("languages_sign")
        n.title = "   " + label
    end for
    m.shown = shown
    m.list.content = root
    m.count.text = ""
end sub

sub onPick()
    e = m.shown[m.list.itemSelected]
    if e = invalid then return
    prefSet("lang", e.c)
    m.top.action = {type: "restart"}
end sub

sub onStop()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "right" and m.kb.isInFocusChain() and m.shown.count() > 0 then
        m.list.setFocus(true)
        return true
    else if key = "left" and m.list.isInFocusChain() then
        m.kb.setFocus(true)
        return true
    end if
    return false
end function
