' Inicio: Destacados, Accesos, Mis favoritos, Continuar viendo, Las buenas noticias, Lo más reciente y categorías.

sub init()
    c = m.global.colors
    m.rl = m.top.findNode("rows")
    m.rl.itemComponentName = bpNs() + "CardItem"
    m.rl.rowLabelColor = c.text
    m.rl.rowLabelFont = "font:MediumBoldSystemFont"
    m.rl.focusBitmapBlendColor = c.focus
    m.rl.observeField("rowItemFocused", "onFocused")
    m.rl.observeField("rowItemSelected", "onSelected")
    m.heroImg = m.top.findNode("heroImg")
    m.preview = m.top.findNode("preview")
    m.preview.observeField("state", "onPreviewState")
    m.top.findNode("fadeLeft").blendColor = c.scrim
    m.top.findNode("fadeBottom").blendColor = c.scrim
    m.heroTitle = m.top.findNode("heroTitle")
    m.heroMeta = m.top.findNode("heroMeta")
    m.heroDesc = m.top.findNode("heroDesc")
    m.heroTitle.color = c.text
    m.heroMeta.color = c.accent
    m.heroDesc.color = c.muted
    m.message = m.top.findNode("message")
    m.message.color = c.muted
    m.previewTimer = m.top.findNode("previewTimer")
    m.previewTimer.observeField("fire", "startPreview")
    m.heroTimer = m.top.findNode("heroTimer")
    m.heroTimer.observeField("fire", "showHero")
    m.rebuildTimer = m.top.findNode("rebuildTimer")
    m.rebuildTimer.observeField("fire", "rebuild")
    m.stopTimer = m.top.findNode("stopTimer")
    m.stopTimer.observeField("fire", "stopPreview")
    m.tasks = {}
    m.data = {}
    m.order = []
    m.map = []
    m.rowIds = []
    m.dirty = {}
end sub

sub onStart()
    m.lang = m.global.lang
    m.order = ["featured", "shortcuts", "favorites", "continue", "goodnews", "latest"]
    m.data.shortcuts = {id: "shortcuts", title: tx("shortcuts"), items: shortcuts(m.lang, invalid)}
    localRows()
    rebuild()
    m.rl.setFocus(true)
    runReq({type: "featured", lang: m.lang, id: "featured"})
    runReq({type: "gnHome", lang: m.lang, id: "gn"})
    runReq({type: "latest", lang: m.lang, id: "latest"})
    runReq({type: "homeRows", lang: m.lang, id: "homeRows"})
end sub

sub runReq(req as object)
    t = bpNode("ApiTask")
    t.observeField("response", "onResponse")
    t.request = req
    t.control = "RUN"
    m.tasks[req.id] = t
end sub

sub onResponse(e as object)
    r = e.getData()
    id = r.id
    m.tasks.Delete(id)
    m.dirty[id] = true
    if id = "featured" then
        m.data.featured = {id: "featured", title: tx("featured"), items: r.items}
    else if id = "latest" then
        m.data.latest = {id: "latest", title: tx("latest"), items: r.items}
    else if id = "gn" then
        m.data.shortcuts = {id: "shortcuts", title: tx("shortcuts"), items: r.shortcuts}
        m.dirty.shortcuts = true
        gnRow(r.gn)
    else if id = "homeRows" then
        for each row in r.rows
            m.order.push("cat:" + row.id)
            runReq({type: "row", lang: m.lang, key: row.id, latest: row.latest, id: "cat:" + row.id, title: row.title})
            m.data["cat:" + row.id] = {id: "cat:" + row.id, title: row.title, items: []}
        end for
    else if Left(id, 4) = "cat:" then
        row = m.data[id]
        if row <> invalid and r.row <> invalid then
            if r.row.name <> "" then row.title = r.row.name
            row.items = r.row.items
            row.viewAll = r.row.viewAll
        end if
        if row <> invalid then row.loaded = true
    end if
    m.rebuildTimer.control = "start"
end sub

' Las buenas noticias según Jesús: episodios (más nuevos primero) y aviso de episodio nuevo.
sub gnRow(gn as object)
    eps = []
    for i = gn.episodes.count() - 1 to 0 step -1
        eps.push(gn.episodes[i])
    end for
    title = gn.name
    st = regJson("gn", "state", invalid)
    nowS = nowSec()
    if st = invalid then
        ' primera vez: lo publicado hace más de 30 días cuenta como visto
        seen = []
        for each ep in gn.episodes
            dt = CreateObject("roDateTime")
            if ep.published <> "" then dt.FromISO8601String(ep.published + "T00:00:00Z")
            if nowS - dt.AsSeconds() > 30 * 86400 then seen.push(ep.key)
        end for
        st = {seen: seen}
        regWriteJson("gn", "state", st)
    end if
    seenMap = {}
    for each k in st.seen
        seenMap[k] = true
    end for
    fresh = []
    for each ep in gn.episodes
        if not seenMap.DoesExist(ep.key) then fresh.push(ep)
    end for
    if fresh.count() > 0 then
        title = title + "  ·  " + tx("gn_new_badge")
        m.top.action = {type: "toast", text: tx("gn_new_title") + ": " + fresh[fresh.count() - 1].title}
    end if
    m.data.goodnews = {id: "goodnews", title: title, items: eps, viewAll: {kind: "category", key: "SeriesGoodNews", name: gn.name, image: invalid, viewAll: true}}
end sub

' Filas que se guardan en el Roku: Mis favoritos y Continuar viendo.
sub localRows()
    favs = []
    imgs = []
    for each e in favList()
        if e.type = "media" then
            mi = normalizeMedia(e.media, e.lang)
            if mi <> invalid then favs.push(mi)
        else if e.type = "image" then
            favs.push({kind: "image", url: e.url, caption: e.caption, title: e.title})
        end if
    end for
    if favs.count() > 0 then
        m.data.favorites = {id: "favorites", title: "♥ " + tx("favorites"), items: favs}
    else
        m.data.Delete("favorites")
    end if
    cont = []
    for each p in progressAll()
        if p.l = m.lang then
            cont.push({kind: "media", key: p.k, naturalKey: p.k, lang: p.l, type: "", title: p.t, description: "", duration: p.d, durationText: fmtTime(p.d), published: "", card: p.i, backdrop: p.i, square: p.i, files: [], isAudio: p.a = true})
        end if
    end for
    if cont.count() > 0 then
        m.data["continue"] = {id: "continue", title: tx("continue_watching"), items: cont}
    else
        m.data.Delete("continue")
    end if
end sub

sub rebuild()
    rows = []
    ids = []
    for each id in m.order
        r = m.data[id]
        if Left(id, 4) = "cat:" and (r = invalid or r.loaded <> true) then exit for ' las categorías aparecen en orden
        if r <> invalid and r.items <> invalid and r.items.count() > 0 then
            rows.push(r)
            ids.push(id)
        end if
    end for
    ' Si solo llegaron filas nuevas al final, se agregan sin tocar las demás (así el foco no salta).
    n = m.rowIds.count()
    canAppend = n > 0 and ids.count() >= n and m.rl.content <> invalid
    if canAppend then
        for i = 0 to n - 1
            if ids[i] <> m.rowIds[i] or m.dirty.DoesExist(ids[i]) then
                canAppend = false
                exit for
            end if
        end for
    end if
    m.dirty = {}
    if canAppend then
        if ids.count() = n then return
        extra = []
        for i = n to ids.count() - 1
            extra.push(rows[i])
        end for
        built = buildRows(extra)
        root = m.rl.content
        sizes = m.rl.rowItemSize
        heights = m.rl.rowHeights
        sp = m.rl.rowItemSpacing
        for i = 0 to built.map.count() - 1
            sizes.push(built.sizes[i])
            heights.push(built.heights[i])
            sp.push([24, 0])
            m.map.push(built.map[i])
        end for
        m.rl.rowItemSize = sizes
        m.rl.rowHeights = heights
        m.rl.rowItemSpacing = sp
        while built.content.getChildCount() > 0
            child = built.content.getChild(0)
            built.content.removeChildIndex(0)
            root.appendChild(child)
        end while
        m.rowIds = ids
        return
    end if
    focusedId = invalid
    focusedCol = 0
    f = m.rl.rowItemFocused
    if f <> invalid and f.count() = 2 and f[0] < m.rowIds.count() then
        focusedId = m.rowIds[f[0]]
        focusedCol = f[1]
    end if
    built = buildRows(rows)
    m.map = built.map
    m.rowIds = ids
    m.rebuilding = true
    applyRows(m.rl, built)
    if focusedId <> invalid and m.userMoved = true then
        for i = 0 to ids.count() - 1
            if ids[i] = focusedId then
                col = focusedCol
                if col >= m.map[i].count() then col = m.map[i].count() - 1
                if i > 0 or col > 0 then m.rl.jumpToRowItem = [i, col]
                exit for
            end if
        end for
    end if
    m.rebuilding = false
    if m.userMoved <> true and m.map.count() > 0 and m.map[0].count() > 0 then
        ' hasta que se use el control, la selección queda en la primera tarjeta (Destacados)
        if m.heroItem = invalid or m.heroItem.key <> m.map[0][0].key then
            m.heroItem = m.map[0][0]
            showHero()
        end if
    end if
end sub

sub onFocused()
    f = m.rl.rowItemFocused
    if f = invalid or f.count() < 2 or f[0] >= m.map.count() then return
    row = m.map[f[0]]
    if f[1] >= row.count() then return
    item = row[f[1]]
    if m.rebuilding <> true and (f[0] > 0 or f[1] > 0) then m.userMoved = true
    m.heroItem = item
    stopPreview()
    m.heroTimer.control = "stop"
    m.heroTimer.control = "start"
end sub

sub showHero()
    item = m.heroItem
    if item = invalid then return
    title = "" : meta = "" : desc = "" : img = invalid
    k = item.kind
    if k = "media" then
        title = item.title
        desc = item.description
        img = item.backdrop
        meta = item.durationText
        if item.published <> "" then meta = meta + "   ·   " + Left(item.published, 4)
    else if k = "tile" then
        title = item.title
        meta = item.subtitle
        img = item.image
    else if k = "category" then
        title = item.name
        img = item.image
    else if k = "image" then
        title = item.caption
        img = item.url
    end if
    m.heroTitle.text = title
    m.heroMeta.text = meta
    m.heroDesc.text = desc
    ' acomodar las líneas
    tb = m.heroTitle.boundingRect()
    m.heroMeta.translation = [0, tb.height + 14]
    m.heroDesc.translation = [0, tb.height + 60]
    if img <> invalid and img <> "" then m.heroImg.uri = img
    m.previewTimer.control = "stop"
    if k = "media" and item.isAudio <> true and item.files <> invalid and item.files.count() > 0 and m.top.active then m.previewTimer.control = "start"
end sub

' Vista previa sin sonido (calidad baja para que cargue rápido).
sub startPreview()
    item = m.heroItem
    if item = invalid or not m.top.active or item.files = invalid then return
    best = invalid
    for each f in item.files
        if f.video = true and f.height > 0 and f.height <= 480 and (best = invalid or f.height > best.height) then best = f
    end for
    if best = invalid then
        for each f in item.files
            if f.video = true then best = f
        end for
    end if
    if best = invalid then return
    c = CreateObject("roSGNode", "ContentNode")
    c.url = best.url
    c.streamFormat = "mp4"
    if item.duration > 120 then c.PlayStart = 20
    m.preview.content = c
    m.preview.visible = true
    m.preview.opacity = 0
    m.preview.control = "play"
    m.stopTimer.control = "start"
end sub

sub onPreviewState()
    st = m.preview.state
    if st = "playing" then
        m.preview.opacity = 1
    else if st = "finished" or st = "error" then
        stopPreview()
    end if
end sub

sub stopPreview()
    m.previewTimer.control = "stop"
    m.stopTimer.control = "stop"
    if m.preview.visible then
        m.preview.control = "stop"
        m.preview.visible = false
        m.preview.opacity = 0
    end if
end sub

sub onPausePreview()
    stopPreview()
end sub

sub onActive()
    if not m.top.active then
        stopPreview()
    else
        m.rl.setFocus(true)
        showHero()
    end if
end sub

sub onRefresh()
    m.dirty.favorites = true
    m.dirty["continue"] = true
    localRows()
    rebuild()
end sub

sub onStop()
    stopPreview()
end sub

sub onGoTop()
    if m.map.count() > 0 then m.rl.jumpToRowItem = [0, 0]
end sub

sub onSelected()
    s = m.rl.rowItemSelected
    if s = invalid or s.count() < 2 or s[0] >= m.map.count() then return
    row = m.map[s[0]]
    if s[1] >= row.count() then return
    stopPreview()
    m.top.action = {type: "open", item: row[s[1]], list: row}
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "options" then
        f = m.rl.rowItemFocused
        if f <> invalid and f.count() = 2 and f[0] < m.map.count() and f[1] < m.map[f[0]].count() then
            m.top.action = {type: "fav", item: m.map[f[0]][f[1]]}
            m.dirty.favorites = true
            m.dirty[m.rowIds[f[0]]] = true
            localRows()
            rebuild()
        end if
        return true
    end if
    if key = "play" and m.heroItem <> invalid and m.heroItem.kind = "media" then
        stopPreview()
        m.top.action = {type: "play", items: [m.heroItem], index: 0, position: 0}
        return true
    end if
    return false
end function
