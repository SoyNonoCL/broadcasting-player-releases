' Pantalla de filas genérica (los datos vienen de ApiTask "screen" o, para Mis favoritos, del registro).

sub init()
    c = m.global.colors
    m.top.findNode("bg").color = c.bg
    m.title = m.top.findNode("title")
    m.title.color = c.text
    m.message = m.top.findNode("message")
    m.message.color = c.muted
    m.hint = m.top.findNode("hint")
    m.hint.color = c.muted
    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/icons/replay.png"
    m.spinner.poster.width = 64
    m.spinner.poster.height = 64
    m.rl = m.top.findNode("rows")
    m.rl.itemComponentName = bpNs() + "CardItem"
    m.rl.rowLabelColor = c.text
    m.rl.rowLabelFont = "font:MediumBoldSystemFont"
    m.rl.focusBitmapBlendColor = c.focus
    m.rl.observeField("rowItemSelected", "onSelected")
    m.map = []
end sub

sub onParams()
    p = m.top.params
    m.route = p.route
    m.title.text = p.title
    load()
end sub

sub load()
    if m.route = "favorites" then
        showFavorites()
        return
    end if
    m.spinner.visible = true
    m.spinner.control = "start"
    m.task = bpNode("ApiTask")
    m.task.observeField("response", "onData")
    m.task.request = {type: "screen", lang: m.global.lang, route: m.route, id: "screen"}
    m.task.control = "RUN"
end sub

sub onData()
    m.spinner.visible = false
    m.spinner.control = "stop"
    s = m.task.response.screen
    if s = invalid then s = {title: "", rows: [], message: tx("error_loading")}
    show(s)
    ' Las buenas noticias: al abrirla, los episodios cuentan como vistos
    if m.route = "goodnews" and s.episodes <> invalid then
        seen = []
        for each ep in s.episodes
            seen.push(ep.key)
        end for
        regWriteJson("gn", "state", {seen: seen})
    end if
end sub

sub show(s as object)
    if s.title <> invalid and s.title <> "" then m.title.text = s.title
    rows = s.rows
    if rows = invalid then rows = []
    if rows.count() = 0 then
        msg = s.message
        if msg = invalid then msg = tx("error_loading")
        m.message.text = msg
        m.message.visible = true
        m.rl.visible = false
        return
    end if
    m.message.visible = false
    m.rl.visible = true
    built = buildRows(rows, 4, 5)
    m.map = built.map
    applyRows(m.rl, built)
    ' el foco empieza en la primera fila con tarjetas
    for i = 0 to m.map.count() - 1
        if m.map[i].count() > 0 then
            if i > 0 then m.rl.jumpToRowItem = [i, 0]
            exit for
        end if
    end for
    m.rl.setFocus(true)
end sub

' Mis favoritos (guardados en el Roku y sincronizados con Google Drive)
sub showFavorites()
    vids = [] : auds = [] : imgs = [] : urls = [] : caps = []
    for each e in favList()
        if e.type = "media" then
            mi = normalizeMedia(e.media, e.lang)
            if mi <> invalid then
                if mi.isAudio then auds.push(mi) else vids.push(mi)
            end if
        else if e.type = "image" then
            urls.push(e.url)
            caps.push(e.caption)
            imgs.push(e)
        end if
    end for
    rows = []
    if vids.count() > 0 then rows.push({id: "v", title: tx("fav_videos"), grid: true, items: vids})
    if auds.count() > 0 then rows.push({id: "a", title: tx("audio"), grid: true, items: auds})
    if imgs.count() > 0 then
        tiles = []
        for i = 0 to imgs.count() - 1
            e = imgs[i]
            ttl = e.caption
            if ttl = invalid or ttl = "" then ttl = e.title
            tiles.push(tile({id: "fi" + i.toStr(), title: ttl, subtitle: e.title, image: e.url, action: {images: urls, captions: caps, index: i}}))
        end for
        rows.push({id: "i", title: tx("fav_images"), grid: true, items: tiles})
    end if
    show({title: tx("favorites"), rows: rows, message: tx("fav_empty") + Chr(10) + tx("roku_fav_hint")})
    m.hint.text = tx("roku_fav_hint")
    m.hint.visible = rows.count() > 0
end sub

sub onRefresh()
    if m.route = "favorites" then
        showFavorites()
    else if m.map.count() > 0 then
        ' refresca progreso y corazones sin volver a pedir los datos
        f = m.rl.rowItemFocused
        root = m.rl.content
        for r = 0 to m.map.count() - 1
            row = root.getChild(r)
            for c = 0 to m.map[r].count() - 1
                n = row.getChild(c)
                fields = itemFields(m.map[r][c])
                n.setFields({prog: fields.prog, fav: fields.fav, sub: fields.sub})
            end for
        end for
    end if
end sub

sub onSelected()
    s = m.rl.rowItemSelected
    if s = invalid or s.count() < 2 or s[0] >= m.map.count() then return
    row = m.map[s[0]]
    if s[1] >= row.count() then return
    item = row[s[1]]
    ' en la Biblia, el audio se escucha seguido desde el capítulo elegido
    m.top.action = {type: "open", item: item, list: row}
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "options" then
        f = m.rl.rowItemFocused
        if f <> invalid and f.count() = 2 and f[0] < m.map.count() and f[1] < m.map[f[0]].count() then
            m.top.action = {type: "fav", item: m.map[f[0]][f[1]]}
            onRefresh()
        end if
        return true
    end if
    return false
end function
