' Pantalla de filas genérica (los datos vienen de ApiTask "screen" o, para Mis favoritos, del registro).

sub init()
    c = m.global.colors
    m.top.findNode("bg").color = c.bg
    m.title = m.top.findNode("title")
    m.title.color = c.text
    m.message = m.top.findNode("message")
    m.message.color = c.muted
    m.hint = m.top.findNode("hint")
    m.hint.color = c.muted
    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/icons/replay.png"
    m.spinner.poster.width = 64
    m.spinner.poster.height = 64
    m.rl = m.top.findNode("rows")
    m.rl.itemComponentName = bpNs() + "CardItem"
    m.rl.rowLabelColor = c.text
    m.rl.rowLabelFont = "font:MediumBoldSystemFont"
    m.rl.focusBitmapBlendColor = c.focus
    m.rl.observeField("rowItemSelected", "onSelected")
    m.map = []
    m.hero = m.top.findNode("hero")
    m.preview = m.top.findNode("preview")
    m.preview.observeField("state", "onPreviewState")
    m.top.findNode("fadeLeft").blendColor = c.scrim
    m.top.findNode("fadeBottom").blendColor = c.scrim
    m.top.findNode("heroSeries").color = c.accent
    m.top.findNode("heroTitle").color = c.text
    m.top.findNode("heroDesc").color = c.muted
    m.previewTimer = m.top.findNode("previewTimer")
    m.previewTimer.observeField("fire", "startPreview")
end sub

' Las buenas noticias: tráiler sin sonido que se repite arriba de la pantalla.
sub showPreview(item as object, series as string)
    m.pvItem = item
    m.hero.visible = true
    m.title.visible = false
    m.top.findNode("heroImg").uri = item.backdrop
    m.top.findNode("heroSeries").text = UCase(series)
    ht = m.top.findNode("heroTitle")
    ht.text = item.title
    hd = m.top.findNode("heroDesc")
    hd.text = item.description
    hd.translation = [150, 130 + ht.boundingRect().height + 20]
    m.rl.translation = [150, 560]
    m.rl.itemClippingRect = [0, 0, 1770, 520]
    m.previewTimer.control = "start"
end sub

sub startPreview()
    item = m.pvItem
    if item = invalid or m.top.active = false then return
    best = invalid
    for each f in item.files
        if f.video = true and f.height > 0 and f.height <= 480 and (best = invalid or f.height > best.height) then best = f
    end for
    if best = invalid then
        for each f in item.files
            if f.video = true then best = f
        end for
    end if
    if best = invalid then return
    c = CreateObject("roSGNode", "ContentNode")
    c.url = best.url
    c.streamFormat = "mp4"
    m.preview.content = c
    m.preview.visible = true
    m.preview.control = "play"
end sub

sub onPreviewState()
    st = m.preview.state
    if st = "playing" then
        m.preview.opacity = 1
    else if st = "error" then
        stopPreview()
    end if
end sub

sub stopPreview()
    m.previewTimer.control = "stop"
    if m.preview.visible then
        m.preview.control = "stop"
        m.preview.visible = false
        m.preview.opacity = 0
    end if
end sub

sub onActive()
    if m.pvItem = invalid then return
    if m.top.active then m.previewTimer.control = "start" else stopPreview()
end sub

sub onStop()
    stopPreview()
end sub

sub onParams()
    p = m.top.params
    m.route = p.route
    m.title.text = p.title
    load()
end sub

sub load()
    if m.route = "favorites" then
        showFavorites()
        return
    end if
    m.spinner.visible = true
    m.spinner.control = "start"
    m.task = bpNode("ApiTask")
    m.task.observeField("response", "onData")
    m.task.request = {type: "screen", lang: m.global.lang, route: m.route, id: "screen"}
    m.task.control = "RUN"
end sub

sub onData()
    m.spinner.visible = false
    m.spinner.control = "stop"
    s = m.task.response.screen
    if s = invalid then s = {title: "", rows: [], message: tx("error_loading")}
    show(s)
    ' Las buenas noticias: al abrirla, los episodios cuentan como vistos
    if m.route = "goodnews" and s.episodes <> invalid then
        seen = []
        for each ep in s.episodes
            seen.push(ep.key)
        end for
        regWriteJson("gn", "state", {seen: seen})
    end if
end sub

sub show(s as object)
    if s.title <> invalid and s.title <> "" then m.title.text = s.title
    if s.preview <> invalid then showPreview(s.preview, m.title.text)
    rows = s.rows
    if rows = invalid then rows = []
    if rows.count() = 0 then
        msg = s.message
        if msg = invalid then msg = tx("error_loading")
        m.message.text = msg
        m.message.visible = true
        m.rl.visible = false
        return
    end if
    m.message.visible = false
    m.rl.visible = true
    built = buildRows(rows, 4, 5)
    m.map = built.map
    applyRows(m.rl, built)
    ' el foco empieza en la primera fila con tarjetas
    for i = 0 to m.map.count() - 1
        if m.map[i].count() > 0 then
            if i > 0 then m.rl.jumpToRowItem = [i, 0]
            exit for
        end if
    end for
    m.rl.setFocus(true)
end sub

' Mis favoritos (guardados en el Roku y sincronizados con Google Drive)
sub showFavorites()
    vids = [] : auds = [] : imgs = [] : urls = [] : caps = []
    for each e in favList()
        if e.type = "media" then
            mi = normalizeMedia(e.media, e.lang)
            if mi <> invalid then
                if mi.isAudio then auds.push(mi) else vids.push(mi)
            end if
        else if e.type = "image" then
            urls.push(e.url)
            caps.push(e.caption)
            imgs.push(e)
        end if
    end for
    rows = []
    if vids.count() > 0 then rows.push({id: "v", title: tx("fav_videos"), grid: true, items: vids})
    if auds.count() > 0 then rows.push({id: "a", title: tx("audio"), grid: true, items: auds})
    if imgs.count() > 0 then
        tiles = []
        for i = 0 to imgs.count() - 1
            e = imgs[i]
            ttl = e.caption
            if ttl = invalid or ttl = "" then ttl = e.title
            tiles.push(tile({id: "fi" + i.toStr(), title: ttl, subtitle: e.title, image: e.url, action: {images: urls, captions: caps, index: i}}))
        end for
        rows.push({id: "i", title: tx("fav_images"), grid: true, items: tiles})
    end if
    show({title: tx("favorites"), rows: rows, message: tx("fav_empty") + Chr(10) + tx("roku_fav_hint")})
    m.hint.text = tx("roku_fav_hint")
    m.hint.visible = rows.count() > 0
end sub

sub onRefresh()
    if m.route = "favorites" then
        showFavorites()
    else if m.map.count() > 0 then
        ' refresca progreso y corazones sin volver a pedir los datos
        f = m.rl.rowItemFocused
        root = m.rl.content
        for r = 0 to m.map.count() - 1
            row = root.getChild(r)
            for c = 0 to m.map[r].count() - 1
                n = row.getChild(c)
                fields = itemFields(m.map[r][c])
                n.setFields({prog: fields.prog, fav: fields.fav, sub: fields.sub})
            end for
        end for
    end if
end sub

sub onSelected()
    s = m.rl.rowItemSelected
    if s = invalid or s.count() < 2 or s[0] >= m.map.count() then return
    row = m.map[s[0]]
    if s[1] >= row.count() then return
    item = row[s[1]]
    stopPreview()
    ' en la Biblia, el audio se escucha seguido desde el capítulo elegido
    m.top.action = {type: "open", item: item, list: row}
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "options" then
        f = m.rl.rowItemFocused
        if f <> invalid and f.count() = 2 and f[0] < m.map.count() and f[1] < m.map[f[0]].count() then
            m.top.action = {type: "fav", item: m.map[f[0]][f[1]]}
            onRefresh()
        end if
        return true
    end if
    return false
end function
