sub init()
    m.img = m.top.findNode("img")
end sub

sub onParams()
    p = m.top.params
    m.urls = p.urls
    m.caps = p.captions
    if m.caps = invalid then m.caps = []
    m.index = p.index
    show()
    m.top.setFocus(true)
end sub

function current() as object
    cap = ""
    if m.index < m.caps.count() and m.caps[m.index] <> invalid then cap = m.caps[m.index]
    return {kind: "image", url: m.urls[m.index], caption: cap, title: cap}
end function

sub show()
    it = current()
    m.img.uri = it.url
    m.top.findNode("cap").text = it.caption
    if m.urls.count() > 1 then m.top.findNode("count").text = (m.index + 1).toStr() + " / " + m.urls.count().toStr() else m.top.findNode("count").text = ""
    m.top.findNode("heart").visible = favIsOn(it)
end sub

sub onStop()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if (key = "right" or key = "fastforward") and m.index + 1 < m.urls.count() then
        m.index = m.index + 1
        show()
        return true
    else if (key = "left" or key = "rewind") and m.index > 0 then
        m.index = m.index - 1
        show()
        return true
    else if key = "options" then
        m.top.action = {type: "fav", item: current()}
        show()
        return true
    end if
    return key = "left" or key = "right" or key = "up" or key = "down" or key = "OK"
end function
