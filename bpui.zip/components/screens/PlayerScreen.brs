' Reproductor de video.

sub init()
    m.video = m.top.findNode("video")
    m.video.notificationInterval = 5
    m.video.observeField("state", "onState")
    m.video.observeField("position", "onPosition")
    m.info = m.top.findNode("info")
    m.infoTimer = m.top.findNode("infoTimer")
    m.infoTimer.observeField("fire", "hideInfo")
    m.lastSave = 0
end sub

sub onParams()
    p = m.top.params
    m.items = p.items
    m.index = p.index
    m.live = p.live = true
    m.video.enableTrickPlay = not m.live
    startItem(p.position)
    m.video.setFocus(true)
end sub

' Elige el archivo con la mejor calidad que no pase la preferida.
function pickFile(files as object) as dynamic
    maxH = prefGet("quality", "1080").toInt()
    best = invalid
    low = invalid
    for each f in files
        if f.video = true then
            if f.height <= maxH and (best = invalid or f.height > best.height) then best = f
            if low = invalid or f.height < low.height then low = f
        end if
    end for
    if best = invalid then best = low
    if best = invalid and files.count() > 0 then best = files[0]
    return best
end function

sub startItem(position as dynamic)
    item = m.items[m.index]
    m.item = item
    f = pickFile(item.files)
    if f = invalid then
        m.top.action = {type: "toast", text: tx("playback_error")}
        m.top.action = {type: "back"}
        return
    end if
    c = CreateObject("roSGNode", "ContentNode")
    c.url = f.url
    c.title = item.title
    if LCase(Right(f.url, 5)) = ".m3u8" then c.streamFormat = "hls" else c.streamFormat = "mp4"
    if item.description <> invalid then c.description = item.description
    if item.card <> invalid then c.HDPosterUrl = item.card
    if position <> invalid and position > 0 then c.PlayStart = position
    subOn = prefGet("subs", "0") = "1"
    if f.subtitles <> invalid then
        c.SubtitleTracks = [{Language: LCase(m.global.strings._locale), TrackName: f.subtitles, Description: "Subtitles"}]
    end if
    m.video.content = c
    if f.subtitles <> invalid and subOn then
        m.video.globalCaptionMode = "On"
        m.video.subtitleTrack = f.subtitles
    end if
    m.video.control = "play"
    showInfo()
end sub

sub showInfo()
    t = m.top.findNode("infoTitle")
    badge = m.top.findNode("badge")
    badgeBg = m.top.findNode("badgeBg")
    x = 30
    if m.live then
        badge.text = tx("live_badge")
        bw = Len(badge.text) * 16 + 40
        badge.width = bw
        badgeBg.width = bw
        badge.visible = true
        badgeBg.visible = true
        x = bw + 40
    else
        badge.visible = false
        badgeBg.visible = false
    end if
    t.text = m.item.title
    t.translation = [x, 0]
    w = t.boundingRect().width
    if w > 1500 then
        w = 1500
        t.width = 1500
    end if
    m.top.findNode("infoBg").width = x + w + 36
    m.info.visible = true
    m.infoTimer.control = "stop"
    m.infoTimer.control = "start"
end sub

sub hideInfo()
    m.info.visible = false
end sub

sub onPosition()
    if m.live then return
    posSec = Int(m.video.position)
    if Abs(posSec - m.lastSave) >= 10 then
        m.lastSave = posSec
        saveProgress()
    end if
end sub

sub saveProgress()
    if m.live or m.item = invalid then return
    d = m.item.duration
    if (d = invalid or d = 0) and m.video.duration > 0 then d = Int(m.video.duration)
    if d = invalid or d <= 0 then return
    progressSave(m.item, Int(m.video.position), d)
end sub

sub onState()
    st = m.video.state
    if st = "finished" then
        if not m.live then progressSave(m.item, m.item.duration, m.item.duration)
        if m.index + 1 < m.items.count() then
            m.index = m.index + 1
            m.lastSave = 0
            startItem(0)
        else
            m.top.action = {type: "back"}
        end if
    else if st = "error" then
        print "VIDEO ERROR "; m.video.errorCode; " "; m.video.errorMsg
        m.top.action = {type: "toast", text: tx("playback_error")}
        if m.index + 1 < m.items.count() and m.live then
            m.index = m.index + 1
            startItem(0)
        else
            m.top.action = {type: "back"}
        end if
    else if st = "paused" then
        saveProgress()
    end if
end sub

sub onStop()
    saveProgress()
    m.video.control = "stop"
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "up" or key = "info" then
        showInfo()
        return true
    end if
    if m.live and (key = "right" or key = "left" or key = "fastforward" or key = "rewind") then
        ' En vivo: → pasa al siguiente video del canal
        if key = "right" or key = "fastforward" then
            if m.index + 1 < m.items.count() then
                m.index = m.index + 1
                startItem(0)
            end if
        end if
        return true
    end if
    return false
end function

' Órdenes del teléfono ("Mi TV").
sub onControl()
    c = m.top.control
    if c.cmd = "toggle" then
        if m.video.state = "playing" then m.video.control = "pause" else m.video.control = "resume"
    else if c.cmd = "seek" and not m.live then
        d = 0
        if c.delta <> invalid then d = c.delta.toInt()
        p = m.video.position + d
        if p < 0 then p = 0
        m.video.seek = p
    else if c.cmd = "next" and m.index + 1 < m.items.count() then
        saveProgress()
        m.index = m.index + 1
        startItem(0)
    end if
end sub
