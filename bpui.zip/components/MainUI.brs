' Controlador principal de la app de Roku.

sub init()
    m.screens = m.top.findNode("screens")
    m.menuLayer = m.top.findNode("menuLayer")
    m.overlay = m.top.findNode("overlay")
    m.toast = m.top.findNode("toast")
    m.toastBg = m.top.findNode("toastBg")
    m.toastText = m.top.findNode("toastText")
    m.toastTimer = m.top.findNode("toastTimer")
    m.toastTimer.observeField("fire", "hideToast")
    m.stack = []
    m.tasks = {}
end sub

sub onStart()
    if not m.top.start then return
    lang = contentLanguage()
    loadStrings(lang)
    loadTheme()
    m.lang = lang
    buildHome()
    ' Favoritos: trae los cambios de Google Drive (por ejemplo, los marcados en otra TV).
    st = regRead("drive", "refresh")
    last = regRead("drive", "last", "0").toInt()
    if st <> invalid and nowSec() - last > 1800 then runTask({type: "driveSync", id: "autosync"}, "onAutoSync")
    ' Aviso de actualización (la nueva versión se usa al abrir la app; esto solo informa)
    seen = regRead("prefs", "ui_seen", "0").toInt()
    if m.top.uiVersion > seen then
        if seen > 0 then showToast(tx("roku_updated", appVersionText()))
        regWrite("prefs", "ui_seen", m.top.uiVersion.toStr())
    end if
end sub

function appVersionText() as string
    ai = CreateObject("roAppInfo")
    return ai.GetVersion() + " · UI " + m.top.uiVersion.toStr()
end function

' Vuelve a construir todo (al cambiar el idioma o la apariencia).
sub restartUi()
    while m.stack.count() > 0
        s = m.stack.pop()
        stopScreen(s)
        m.screens.removeChild(s)
    end while
    m.menuLayer.removeChildrenIndex(m.menuLayer.getChildCount(), 0)
    m.lang = contentLanguage()
    loadStrings(m.lang)
    loadTheme()
    buildHome()
end sub

sub buildHome()
    c = m.global.colors
    m.top.findNode("bg").color = c.bg
    m.home = bpNode("HomeScreen")
    m.home.observeField("action", "onAction")
    pushScreen(m.home)
    m.menu = bpNode("SideMenu")
    m.menu.observeField("selected", "onMenu")
    m.menu.observeField("closed", "onMenuClosed")
    m.menuLayer.appendChild(m.menu)
    m.home.start = true
end sub

' ---------------- Pantallas ----------------
sub pushScreen(s as object)
    if m.stack.count() > 0 then
        top = m.stack[m.stack.count() - 1]
        top.visible = false
        top.active = false
    end if
    m.screens.appendChild(s)
    m.stack.push(s)
    s.visible = true
    s.active = true
    s.setFocus(true)
    if m.menu <> invalid then m.menu.visible = (m.stack.count() = 1)
end sub

sub popScreen()
    if m.stack.count() <= 1 then return
    s = m.stack.pop()
    stopScreen(s)
    m.screens.removeChild(s)
    top = m.stack[m.stack.count() - 1]
    top.visible = true
    top.active = true
    top.refresh = true
    top.setFocus(true)
    if m.menu <> invalid then m.menu.visible = (m.stack.count() = 1)
end sub

sub stopScreen(s as object)
    if s.hasField("stop") then s.stop = true
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back" then
        if m.stack.count() > 1 then
            popScreen()
            return true
        end if
        return false
    end if
    if key = "left" and m.stack.count() = 1 and m.menu <> invalid then
        m.menu.expanded = true
        m.menu.setFocus(true)
        m.home.active = false
        return true
    end if
    return false
end function

sub onMenuClosed()
    if m.menu.closed then
        m.home.active = true
        m.home.setFocus(true)
    end if
end sub

sub onMenu()
    id = m.menu.selected
    m.menu.expanded = false
    m.home.active = true
    m.home.setFocus(true)
    if id = "home" then
        m.home.goTop = true
    else if id = "search" then
        openScreen("SearchScreen", {})
    else if id = "favorites" then
        openRoute("favorites", tx("favorites"))
    else if id = "categories" then
        openRoute("categories", tx("categories"))
    else if id = "language" then
        openScreen("LanguageScreen", {})
    else if id = "settings" then
        openScreen("SettingsScreen", {uiVersion: m.top.uiVersion})
    end if
end sub

sub openScreen(name as string, params as object)
    s = bpNode(name)
    if s = invalid then return
    s.observeField("action", "onAction")
    s.params = params
    pushScreen(s)
end sub

sub openRoute(route as string, title as string)
    openScreen("RowsScreen", {route: route, title: title})
end sub

' ---------------- Acciones que piden las pantallas ----------------
sub onAction(e as object)
    a = e.getData()
    if a = invalid then return
    t = a.type
    if t = "open" then
        openItem(a.item, a.list)
    else if t = "play" then
        play(a.items, a.index, a.position)
    else if t = "live" then
        playLive()
    else if t = "route" then
        openRoute(a.route, a.title)
    else if t = "back" then
        popScreen()
    else if t = "toast" then
        showToast(a.text)
    else if t = "restart" then
        restartUi()
    else if t = "fav" then
        toggleFavorite(a.item)
    else if t = "screen" then
        openScreen(a.name, a.params)
    end if
end sub

sub toggleFavorite(item as dynamic)
    if favTarget(item) = invalid then return
    on = favToggle(item)
    if on then showToast(tx("fav_added")) else showToast(tx("fav_removed"))
    if regRead("drive", "refresh") <> invalid then runTask({type: "driveSync", id: "favsync"}, "onAutoSync")
end sub

sub openItem(item as dynamic, list as dynamic)
    if item = invalid then return
    k = item.kind
    if k = "media" then
        if item.isAudio = true then
            q = []
            if list <> invalid then
                for each x in list
                    if x.kind = "media" and x.isAudio = true then q.push(x)
                end for
            end if
            if q.count() = 0 then q = [item]
            idx = 0
            for i = 0 to q.count() - 1
                if q[i].key = item.key then idx = i
            end for
            p = progressGet(item)
            posSec = 0
            if p <> invalid then posSec = p.p
            play(q, idx, posSec)
        else
            openScreen("DetailsScreen", {item: item})
        end if
    else if k = "category" then
        if item.key = "SeriesGoodNews" then
            openRoute("goodnews", item.name)
        else
            openRoute("category/" + item.key, item.name)
        end if
    else if k = "image" then
        openScreen("ImageViewer", {urls: [item.url], captions: [item.caption], index: 0})
    else if k = "tile" then
        a = item.action
        if a = invalid then return
        if a.open <> invalid then
            title = a.title
            if title = invalid then title = item.title
            openRoute(a.open, title)
        else if a.live = true then
            playLive()
        else if a.play <> invalid then
            mi = a.play[a.index]
            p = progressGet(mi)
            posSec = 0
            if p <> invalid then posSec = p.p
            play(a.play, a.index, posSec)
        else if a.images <> invalid then
            openScreen("ImageViewer", {urls: a.images, captions: a.captions, index: a.index})
        else if a.qr <> invalid then
            openScreen("QrScreen", {url: "https://www.jw.org/" + webLocale(m.lang) + "/"})
        end if
    end if
end sub

sub play(items as object, index as integer, position as dynamic)
    if items = invalid or items.count() = 0 then return
    if position = invalid then position = 0
    if m.home <> invalid then m.home.pausePreview = true
    item = items[index]
    if item.files = invalid or item.files.count() = 0 then
        ' favoritos o enlaces de "Mi TV": se buscan los archivos antes de reproducir
        keys = []
        for each it in items
            keys.push(it.key)
        end for
        m.pendingPlay = {index: index, position: position}
        runTask({type: "media", lang: item.lang, keys: keys, id: "resolve"}, "onResolved")
        return
    end if
    if item.isAudio = true then
        openScreen("AudioScreen", {items: items, index: index, position: position})
    else
        openScreen("PlayerScreen", {items: items, index: index, position: position, live: false})
    end if
end sub

sub onResolved(e as object)
    r = e.getData()
    if r.items = invalid or r.items.count() = 0 then
        showToast(tx("playback_error"))
        return
    end if
    idx = m.pendingPlay.index
    if idx >= r.items.count() then idx = 0
    play(r.items, idx, m.pendingPlay.position)
end sub

sub playLive()
    showToast(tx("live_loading"))
    runTask({type: "live", lang: m.lang, id: "live"}, "onLive")
end sub

sub onLive(e as object)
    r = e.getData()
    hideToast()
    if r.live = invalid then
        showToast(tx("error_loading"))
        return
    end if
    if m.home <> invalid then m.home.pausePreview = true
    openScreen("PlayerScreen", {items: r.live.items, index: 0, position: r.live.position, live: true})
end sub

' ---------------- "Mi TV": órdenes desde el teléfono o Windows ----------------
' Parámetros: contentId (clave del video), lang, list (claves separadas por coma), posSec (segundos), live=1
sub onDeepLink()
    a = m.top.deepLink
    if a = invalid then return
    ' control remoto desde el teléfono: cmd = toggle | seek (delta en segundos) | next | stop
    if a.cmd <> invalid then
        top = m.stack[m.stack.count() - 1]
        if a.cmd = "stop" then
            if m.stack.count() > 1 and top.hasField("control") then popScreen()
        else if top.hasField("control") then
            top.control = {cmd: a.cmd, delta: a.delta}
        end if
        return
    end if
    if a.live = "1" or a.contentId = "live" then
        closeToHome()
        playLive()
        return
    end if
    if a.contentId = invalid or a.contentId = "" then return
    lang = a.lang
    if lang = invalid or lang = "" then lang = m.lang
    keys = [a.contentId]
    if a.list <> invalid and a.list <> "" then keys = a.list.Split(",")
    idx = 0
    for i = 0 to keys.count() - 1
        if keys[i] = a.contentId then idx = i
    end for
    posSec = 0
    if a.pos <> invalid then posSec = a.pos.toInt()
    closeToHome()
    m.pendingPlay = {index: idx, position: posSec}
    runTask({type: "media", lang: lang, keys: keys, id: "deeplink"}, "onResolved")
end sub

sub closeToHome()
    while m.stack.count() > 1
        popScreen()
    end while
end sub

' ---------------- Tareas ----------------
sub runTask(req as object, callback as string)
    t = bpNode("ApiTask")
    t.observeField("response", callback)
    t.request = req
    t.control = "RUN"
    m.tasks[req.id] = t
end sub

sub onAutoSync(e as object)
    r = e.getData()
    if r.sync <> invalid and r.sync.ok = true and r.sync.restored > 0 then
        showToast(tx("drive_restored", r.sync.restored))
        if m.home <> invalid then m.home.refresh = true
    end if
end sub

' ---------------- Avisos ----------------
sub showToast(text as string)
    m.toastText.text = text
    w = Len(text) * 15 + 120
    if w > 1500 then w = 1500
    if w < 360 then w = 360
    x = (1920 - w) / 2
    m.toastBg.width = w
    m.toastBg.translation = [x, 0]
    m.toastText.width = w
    m.toastText.translation = [x, 0]
    m.toast.visible = true
    m.toastTimer.control = "stop"
    m.toastTimer.control = "start"
end sub

sub hideToast()
    m.toast.visible = false
end sub
