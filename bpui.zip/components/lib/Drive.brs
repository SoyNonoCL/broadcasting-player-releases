' Respaldo de "Mis favoritos" en Google Drive (carpeta privada de la app), con inicio de sesión por código.
' Mismo proyecto de Google y mismo archivo que la TV, el teléfono y Windows.

function driveConst() as object
    return {
        CLIENT_ID: "570249905215-u8m2eikj2j0kj0hlgqgdqurc4t9r3gks.apps.googleusercontent.com"
        CLIENT_SECRET: "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"
        SCOPE: "https://www.googleapis.com/auth/drive.appdata email"
        FILE_NAME: "broadcasting-player-favoritos.json"
        OAUTH: "https://oauth2.googleapis.com"
        API: "https://www.googleapis.com"
    }
end function

function formBody(params as object) as string
    parts = []
    for each k in params
        parts.push(k + "=" + urlEncode(params[k]))
    end for
    return parts.Join("&")
end function

function driveStatus() as object
    return {connected: regRead("drive", "refresh") <> invalid, email: regRead("drive", "email", ""), lastSync: regRead("drive", "last", "0").toInt()}
end function

function driveStartDeviceFlow() as dynamic
    c = driveConst()
    r = httpRequest(c.OAUTH + "/device/code", "POST", formBody({client_id: c.CLIENT_ID, scope: c.SCOPE}), {"Content-Type": "application/x-www-form-urlencoded"})
    if r.code <> 200 then return {error: "device/code " + r.code.toStr() + " " + Left(r.body, 120)}
    j = ParseJson(r.body)
    url = j.verification_url
    if url = invalid then url = j.verification_uri
    if url = invalid then url = "https://www.google.com/device"
    interval = 5
    if j.interval <> invalid then interval = j.interval
    expires = 1800
    if j.expires_in <> invalid then expires = j.expires_in
    return {deviceCode: j.device_code, userCode: j.user_code, url: url, interval: interval, expiresIn: expires}
end function

function driveWaitForAuthorization(dc as object) as boolean
    c = driveConst()
    endAt = nowSec() + dc.expiresIn
    interval = dc.interval
    if interval < 1 then interval = 1
    while nowSec() < endAt
        sleep(interval * 1000)
        r = httpRequest(c.OAUTH + "/token", "POST", formBody({client_id: c.CLIENT_ID, client_secret: c.CLIENT_SECRET, device_code: dc.deviceCode, grant_type: "urn:ietf:params:oauth:grant-type:device_code"}), {"Content-Type": "application/x-www-form-urlencoded"})
        j = ParseJson(r.body)
        if j = invalid then j = {}
        if r.code = 200 and j.refresh_token <> invalid then
            regWrite("drive", "refresh", j.refresh_token)
            regWrite("drive", "access", j.access_token)
            regWrite("drive", "expires", (nowSec() + 3300).toStr())
            me = httpRequest(c.API + "/oauth2/v3/userinfo", "GET", "", {Authorization: "Bearer " + j.access_token})
            if me.code = 200 then
                mj = ParseJson(me.body)
                if mj <> invalid and mj.email <> invalid then regWrite("drive", "email", mj.email)
            end if
            return true
        end if
        err = j.error
        if err = "slow_down" then
            interval = interval + 5
        else if err <> "authorization_pending" then
            return false
        end if
    end while
    return false
end function

sub driveDisconnect()
    sec = CreateObject("roRegistrySection", "drive")
    for each k in sec.GetKeyList()
        sec.Delete(k)
    end for
    sec.Flush()
end sub

function driveToken() as dynamic
    exp = regRead("drive", "expires", "0").toInt()
    acc = regRead("drive", "access")
    if acc <> invalid and nowSec() < exp then return acc
    refresh = regRead("drive", "refresh")
    if refresh = invalid then return invalid
    c = driveConst()
    r = httpRequest(c.OAUTH + "/token", "POST", formBody({client_id: c.CLIENT_ID, client_secret: c.CLIENT_SECRET, refresh_token: refresh, grant_type: "refresh_token"}), {"Content-Type": "application/x-www-form-urlencoded"})
    if r.code = 400 or r.code = 401 then
        driveDisconnect()
        return invalid
    end if
    if r.code <> 200 then return invalid
    j = ParseJson(r.body)
    regWrite("drive", "access", j.access_token)
    regWrite("drive", "expires", (nowSec() + 3300).toStr())
    return j.access_token
end function

function stampOf(e as dynamic) as dynamic
    if e = invalid then return 0
    a = e.added
    if a = invalid then a = 0
    rm = e.removed
    if rm = invalid then rm = 0
    if rm > a then return rm
    return a
end function

' Junta los favoritos del Roku con los de Drive y sube el resultado.
' Las entradas que vienen de otros equipos se conservan completas en Drive.
function driveSync() as object
    c = driveConst()
    token = driveToken()
    if token = invalid then return {ok: false, error: "no conectado"}
    auth = {Authorization: "Bearer " + token}
    q = urlEncode("name='" + c.FILE_NAME + "'")
    lr = httpRequest(c.API + "/drive/v3/files?spaces=appDataFolder&q=" + q + "&fields=files(id,modifiedTime)", "GET", "", auth)
    if lr.code <> 200 then return {ok: false, error: "list " + lr.code.toStr()}
    lj = ParseJson(lr.body)
    fileId = invalid
    if lj <> invalid and lj.files <> invalid and lj.files.count() > 0 then fileId = lj.files[0].id
    remote = {}
    if fileId <> invalid then
        dl = httpRequest(c.API + "/drive/v3/files/" + fileId + "?alt=media", "GET", "", auth)
        if dl.code = 200 then
            rj = ParseJson(dl.body)
            if rj <> invalid and rj.items <> invalid then remote = rj.items
        end if
    end if
    localAll = favAll()
    before = favList().count()
    merged = {}
    changedLocal = false
    changedRemote = fileId = invalid
    for each k in remote
        merged[k] = remote[k]
    end for
    for each k in localAll
        le = localAll[k]
        re = remote[k]
        if re = invalid or stampOf(le) > stampOf(re) then
            if re <> invalid and le.type = "media" and re.media <> invalid then le.media = re.media
            merged[k] = le
            changedRemote = true
        end if
    end for
    ' lo nuevo de Drive se guarda (compacto) en el Roku
    for each k in remote
        re = remote[k]
        le = localAll[k]
        if re.type <> invalid and (le = invalid or stampOf(re) > stampOf(le)) then
            ce = {type: re.type, added: re.added, removed: re.removed}
            if ce.removed = invalid then ce.removed = 0
            if re.type = "media" then
                ce.lang = re.lang
                mi = normalizeMedia(re.media, re.lang)
                if mi <> invalid then ce.media = favMediaJson(mi)
            else
                ce.url = re.url : ce.caption = re.caption : ce.title = re.title
            end if
            if re.type <> "media" or ce.media <> invalid then
                localAll[k] = ce
                changedLocal = true
            end if
        end if
    end for
    if changedLocal then favStore(localAll)
    if changedRemote then
        body = FormatJson({app: "Broadcasting Player", kind: "favorites", version: 1, exported: nowSec() * 1000&, items: merged})
        if fileId = invalid then
            b = "bp" + nowSec().toStr()
            meta = FormatJson({name: c.FILE_NAME, parents: ["appDataFolder"]})
            mp = "--" + b + Chr(13) + Chr(10) + "Content-Type: application/json; charset=UTF-8" + Chr(13) + Chr(10) + Chr(13) + Chr(10) + meta + Chr(13) + Chr(10)
            mp = mp + "--" + b + Chr(13) + Chr(10) + "Content-Type: application/json" + Chr(13) + Chr(10) + Chr(13) + Chr(10) + body + Chr(13) + Chr(10) + "--" + b + "--" + Chr(13) + Chr(10)
            up = httpRequest(c.API + "/upload/drive/v3/files?uploadType=multipart", "POST", mp, {Authorization: "Bearer " + token, "Content-Type": "multipart/related; boundary=" + b})
        else
            up = httpRequest(c.API + "/upload/drive/v3/files/" + fileId + "?uploadType=media", "PATCH", body, {Authorization: "Bearer " + token, "Content-Type": "application/json"})
        end if
        if up.code < 200 or up.code >= 300 then return {ok: false, error: "upload " + up.code.toStr()}
    end if
    regWrite("drive", "last", nowSec().toStr())
    after = favList().count()
    restored = after - before
    if restored < 0 then restored = 0
    return {ok: true, total: after, restored: restored}
end function
