' Convierte filas de datos en el contenido de un RowList.
' rows = [{id, title, items, grid?, header?, viewAll?}]; devuelve {content, map: [[items de cada fila]], sizes}

function cardSize(item as object) as object
    if item.kind = "tile" and item.compact = true then return [300, 230]
    return [400, 300]
end function

function itemFields(item as object) as object
    f = {title: "", sub: "", img: "", icon: "", txt: "", col: m.global.colors.card, prog: 0.0, fav: false}
    k = item.kind
    if k = "media" then
        f.title = item.title
        f.sub = item.durationText
        if item.isAudio = true and item.durationText <> "" then f.sub = item.durationText
        if item.card <> invalid then f.img = item.card
        p = progressGet(item)
        if p <> invalid and p.d > 0 then
            f.prog = p.p / p.d
            f.sub = tx("remaining", fmtTime(p.d - p.p))
        end if
    else if k = "category" then
        if item.viewAll = true then
            f.title = tx("view_all")
            f.sub = item.name
            f.icon = "tiles/card_view_all.png"
        else
            f.title = item.name
            if item.image <> invalid then f.img = item.image
        end if
    else if k = "tile" then
        f.title = item.title
        if item.subtitle <> invalid then f.sub = item.subtitle
        if item.image <> invalid then
            f.img = item.image
        else if item.icon <> invalid then
            f.icon = item.icon
        else
            f.txt = item.text
            if f.txt = invalid then f.txt = item.title
            f.col = hexColor(item.color)
        end if
    else if k = "image" then
        f.title = item.caption
        if f.title = "" then f.title = item.title
        f.img = item.url
    end if
    f.fav = favIsOn(item)
    return f
end function

function itemNode(item as object) as object
    n = CreateObject("roSGNode", "ContentNode")
    n.addFields(itemFields(item))
    return n
end function

function buildRows(rows as object, perRowGrid = 4 as integer, perRowCompact = 5 as integer) as object
    root = CreateObject("roSGNode", "ContentNode")
    map = [] : sizes = [] : heights = []
    prefix = invalid
    for each r in rows
        if r.header = true then
            ' encabezado ("Esta semana"): se antepone al título de la fila siguiente (una fila vacía no debe recibir el foco)
            prefix = r.title
        else if r.items <> invalid and r.items.count() > 0 then
            items = r.items
            if r.viewAll <> invalid then
                items = []
                items.append(r.items)
                items.push(r.viewAll)
            end if
            sz = cardSize(items[0])
            if r.size <> invalid then sz = r.size
            per = items.count()
            if r.grid = true then
                per = perRowGrid
                if sz[0] < 400 then per = perRowCompact
                if r.perRow <> invalid then per = r.perRow
            end if
            i = 0
            first = true
            while i < items.count()
                row = root.createChild("ContentNode")
                if first then
                    row.title = r.title
                    if prefix <> invalid then row.title = UCase(prefix) + "  ·  " + r.title
                    prefix = invalid
                else
                    row.title = ""
                end if
                chunk = []
                for j = i to i + per - 1
                    if j >= items.count() then exit for
                    chunk.push(items[j])
                    row.appendChild(itemNode(items[j]))
                end for
                map.push(chunk)
                sizes.push(sz)
                h = sz[1] + 70
                if not first then h = sz[1] + 30
                heights.push(h)
                first = false
                i = i + per
            end while
        end if
    end for
    return {content: root, map: map, sizes: sizes, heights: heights}
end function

' Ajusta un RowList a las filas construidas.
sub applyRows(rl as object, built as object)
    rl.rowItemSize = built.sizes
    rl.rowHeights = built.heights
    sp = []
    for each s in built.sizes
        sp.push([24, 0])
    end for
    rl.rowItemSpacing = sp
    rl.content = built.content
end sub
