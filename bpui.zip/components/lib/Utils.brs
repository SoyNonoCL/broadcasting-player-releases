' Utilidades comunes (interfaz y tareas en segundo plano).

' Carpeta del paquete: "pkg:/" (instalado) o "libpkg:/" (versión descargada desde GitHub).
function bpRoot() as string
    r = m.global.root
    if r = invalid or r = "" then return "pkg:/"
    return r
end function

function bpNs() as string
    n = m.global.ns
    if n = invalid then return ""
    return n
end function

' Crea un componente de la app (con el prefijo de la biblioteca cuando corresponde).
function bpNode(name as string) as object
    n = CreateObject("roSGNode", bpNs() + name)
    if n = invalid then n = CreateObject("roSGNode", name)
    return n
end function

function readJson(path as string) as dynamic
    text = ReadAsciiFile(path)
    if text = invalid or text = "" then return invalid
    return ParseJson(text)
end function

' Texto en el idioma de los menús. args: lista de valores para {1}, {2}...
function tx(key as string, args = invalid as dynamic) as string
    if m.bpStrings = invalid then m.bpStrings = m.global.strings
    s = invalid
    if m.bpStrings <> invalid then s = m.bpStrings[key]
    if s = invalid then s = key
    if type(s) <> "roString" and type(s) <> "String" then return key
    if args <> invalid then
        if type(args) <> "roArray" then args = [args]
        for i = 0 to args.count() - 1
            s = s.Replace("{" + (i + 1).toStr() + "}", toText(args[i]))
        end for
    end if
    return s
end function

function toText(v as dynamic) as string
    if v = invalid then return ""
    t = type(v)
    if t = "roString" or t = "String" then return v
    if t = "roInt" or t = "Integer" or t = "roLongInteger" or t = "LongInteger" then return v.toStr()
    if t = "roFloat" or t = "Float" or t = "Double" or t = "roDouble" then return Str(v).Trim()
    if t = "roBoolean" or t = "Boolean" then
        if v then return "true"
        return "false"
    end if
    return ""
end function

' Plural: pl_<clave> = {one, few, many, other}
function plural(key as string, n as integer) as string
    if m.bpStrings = invalid then m.bpStrings = m.global.strings
    forms = m.bpStrings["pl_" + key]
    if forms = invalid then return n.toStr()
    ui = m.bpStrings._ui
    cat = "other"
    n10 = n mod 10 : n100 = n mod 100
    if ui = "U" or ui = "K" then
        if n10 = 1 and n100 <> 11 then
            cat = "one"
        else if n10 >= 2 and n10 <= 4 and (n100 < 12 or n100 > 14) then
            cat = "few"
        else
            cat = "many"
        end if
    else if ui = "P" then
        if n = 1 then
            cat = "one"
        else if n10 >= 2 and n10 <= 4 and (n100 < 12 or n100 > 14) then
            cat = "few"
        else
            cat = "many"
        end if
    else if ui = "B" then
        if n = 1 then
            cat = "one"
        else if n >= 2 and n <= 4 then
            cat = "few"
        end if
    else if ui = "J" or ui = "KO" or ui = "CHS" or ui = "CH" or ui = "SI" or ui = "VT" or ui = "IN" then
        cat = "other"
    else if n = 1 then
        cat = "one"
    end if
    f = forms[cat]
    if f = invalid then f = forms.other
    if f = invalid then return n.toStr()
    return f.Replace("{1}", n.toStr())
end function

function fmtTime(sec as dynamic) as string
    s = Int(sec)
    if s < 0 then s = 0
    h = s \ 3600 : mi = (s mod 3600) \ 60 : se = s mod 60
    ss = se.toStr()
    if se < 10 then ss = "0" + ss
    if h > 0 then
        ms = mi.toStr()
        if mi < 10 then ms = "0" + ms
        return h.toStr() + ":" + ms + ":" + ss
    end if
    return mi.toStr() + ":" + ss
end function

' ---------------- Texto para buscar (sin tildes ni mayúsculas) ----------------
function accentMap() as object
    if m.bpAccents <> invalid then return m.bpAccents
    src = "áàâäãåāăąçćčďéèêëēėęěíìîïīįıñńňóòôöõøōőřśšşșťţțúùûüūůűųýÿžźżđ"
    dst = "aaaaaaaaacccdeeeeeeeeiiiiiiinnnoooooooorsssstttuuuuuuuuyyzzzd"
    mp = {}
    for i = 1 to Len(src)
        mp[Mid(src, i, 1)] = Mid(dst, i, 1)
    end for
    m.bpAccents = mp
    return mp
end function

function normText(s as dynamic) as string
    if s = invalid then return ""
    low = LCase(s)
    mp = accentMap()
    out = ""
    n = Len(low)
    for i = 1 to n
        c = Mid(low, i, 1)
        r = mp[c]
        if r <> invalid then
            out = out + r
        else
            code = Asc(c)
            if (code >= 48 and code <= 57) or (code >= 97 and code <= 122) or code > 127 then
                ' letras y números (incluye otros alfabetos); los signos de puntuación comunes son separadores
                if code = 171 or code = 187 or code = 8220 or code = 8221 or code = 8216 or code = 8217 or code = 8211 or code = 8212 or code = 183 or code = 8230 or code = 191 or code = 161 or (code >= 12288 and code <= 12351) or (code >= 65280 and code <= 65295) then
                    out = out + " "
                else
                    out = out + c
                end if
            else
                out = out + " "
            end if
        end if
    end for
    return collapseSpaces(out)
end function

function collapseSpaces(s as string) as string
    re = CreateObject("roRegex", "\s+", "")
    return re.ReplaceAll(s, " ").Trim()
end function

function queryWords(q as dynamic) as object
    out = []
    for each w in normText(q).Split(" ")
        if w <> "" then out.push(w)
    end for
    return out
end function

' ¿Es japonés, chino, coreano, tailandés...? (no separan las palabras con espacios)
function noSpaces(w as string) as boolean
    for i = 1 to Len(w)
        c = Asc(Mid(w, i, 1))
        if (c >= 3584 and c <= 3839) or (c >= 4096 and c <= 4255) or (c >= 6016 and c <= 6143) or (c >= 12352 and c <= 12543) or (c >= 13312 and c <= 40959) or (c >= 44032 and c <= 55215) then return true
    end for
    return false
end function

' Palabras que empiezan así ("familia" → familia, familias, familiar). Las de 1-2 letras deben ser exactas.
function matchesWords(text as dynamic, words as object) as boolean
    if words.count() = 0 then return true
    norm = normText(text)
    tokens = norm.Split(" ")
    for each w in words
        found = false
        if noSpaces(w) then
            found = Instr(1, norm, w) > 0
        else
            lw = Len(w)
            for each tk in tokens
                if tk = w or (lw >= 3 and Left(tk, lw) = w) then
                    found = true
                    exit for
                end if
            end for
        end if
        if not found then return false
    end for
    return true
end function

' ---------------- Registro (lo que se guarda en el Roku) ----------------
function regRead(section as string, key as string, def = invalid as dynamic) as dynamic
    sec = CreateObject("roRegistrySection", section)
    if sec.Exists(key) then return sec.Read(key)
    return def
end function

sub regWrite(section as string, key as string, value as string)
    sec = CreateObject("roRegistrySection", section)
    sec.Write(key, value)
    sec.Flush()
end sub

sub regDelete(section as string, key as string)
    sec = CreateObject("roRegistrySection", section)
    sec.Delete(key)
    sec.Flush()
end sub

function regJson(section as string, key as string, def as dynamic) as dynamic
    v = regRead(section, key)
    if v = invalid then return def
    j = ParseJson(v)
    if j = invalid then return def
    return j
end function

sub regWriteJson(section as string, key as string, value as dynamic)
    regWrite(section, key, FormatJson(value))
end sub

function nowSec() as integer
    dt = CreateObject("roDateTime")
    return dt.AsSeconds()
end function

' Fecha local de hoy como AAAAMMDD (+días)
function todayNum(plusDays = 0 as integer) as integer
    dt = CreateObject("roDateTime")
    dt.FromSeconds(dt.AsSeconds() + plusDays * 86400)
    dt.ToLocalTime()
    return dt.GetYear() * 10000 + dt.GetMonth() * 100 + dt.GetDayOfMonth()
end function

function padLeft(n as integer, width as integer) as string
    s = n.toStr()
    while Len(s) < width
        s = "0" + s
    end while
    return s
end function

function hexColor(c as string) as integer
    ' "#3F5F8F" → 0x3F5F8FFF
    h = c.Replace("#", "")
    if Len(h) = 6 then h = h + "FF"
    v = 0&
    for i = 1 to Len(h)
        d = Instr(1, "0123456789ABCDEF", UCase(Mid(h, i, 1))) - 1
        if d < 0 then d = 0
        v = v * 16 + d
    end for
    if v > 2147483647& then v = v - 4294967296&
    return v
end function
