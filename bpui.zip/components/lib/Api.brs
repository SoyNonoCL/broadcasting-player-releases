' Acceso a jw.org (catálogo público). Se usa desde las tareas en segundo plano (ApiTask).

function apiConst() as object
    return {
        MEDIATOR: "https://b.jw-cdn.org/apis/mediator/v1"
        SEARCH: "https://b.jw-cdn.org/apis/search/results"
        TOKEN: "https://b.jw-cdn.org/tokens/jworg.jwt"
        PUBMEDIA: "https://b.jw-cdn.org/apis/pub-media/GETPUBMEDIALINKS"
        FEED: "https://raw.githubusercontent.com/SoyNonoCL/broadcasting-player-releases/feed"
        REL: "https://raw.githubusercontent.com/SoyNonoCL/broadcasting-player-releases/main"
        GN_KEY: "SeriesGoodNews"
        GN_KEY_AD: "SeriesGoodNewsAD"
        GN_TRAILER: "pub-gnj_900_VIDEO"
        GN_TRAILER_AD: "pub-gnj_950_VIDEO"
        MAX_ROW: 40
    }
end function

' ---------------- Red ----------------
function httpRequest(url as string, method = "GET" as string, body = "" as string, headers = invalid as dynamic, timeoutMs = 20000 as integer) as object
    for attempt = 1 to 2
        port = CreateObject("roMessagePort")
        u = CreateObject("roUrlTransfer")
        u.SetMessagePort(port)
        u.SetUrl(url)
        u.SetCertificatesFile("common:/certs/ca-bundle.crt")
        u.InitClientCertificates()
        u.EnableEncodings(true)
        u.RetainBodyOnError(true)
        u.AddHeader("User-Agent", "Mozilla/5.0 (Roku) BroadcastingPlayer/1.0")
        u.AddHeader("Accept", "application/json, text/plain, */*")
        if headers <> invalid then
            for each k in headers
                u.AddHeader(k, headers[k])
            end for
        end if
        ok = false
        if method = "GET" then
            ok = u.AsyncGetToString()
        else
            u.SetRequest(method)
            ok = u.AsyncPostFromString(body)
        end if
        if ok then
            msg = wait(timeoutMs, port)
            if type(msg) = "roUrlEvent" then
                code = msg.GetResponseCode()
                if code >= 200 and code < 300 then return {code: code, body: msg.GetString()}
                if code = 404 or code = 400 or code = 401 or code = 403 or code = 428 then return {code: code, body: msg.GetString()}
                last = {code: code, body: msg.GetString()}
            else
                u.AsyncCancel()
                last = {code: -1, body: ""}
            end if
        end if
        sleep(500)
    end for
    if last = invalid then last = {code: -1, body: ""}
    return last
end function

' GET con caché en la memoria temporal del Roku (tmp:), por defecto 30 minutos.
function cachedGet(url as string, ttlSec = 1800 as integer) as dynamic
    d = CreateObject("roEVPDigest")
    d.Setup("md5")
    ba = CreateObject("roByteArray")
    ba.FromAsciiString(url)
    file = "tmp:/c_" + d.Process(ba) + ".json"
    fs = CreateObject("roFileSystem")
    if ttlSec > 0 and fs.Exists(file) then
        st = fs.Stat(file)
        if st <> invalid and st.mtime <> invalid then
            age = nowSec() - st.mtime.AsSeconds()
            if age >= 0 and age < ttlSec then
                text = ReadAsciiFile(file)
                if text <> invalid and text <> "" then return text
            end if
        end if
    end if
    r = httpRequest(url)
    if r.code >= 200 and r.code < 300 then
        WriteAsciiFile(file, r.body)
        return r.body
    end if
    ' sin conexión: se usa la copia anterior si existe
    if fs.Exists(file) then return ReadAsciiFile(file)
    return invalid
end function

function getJson(url as string, ttlSec = 1800 as integer) as dynamic
    text = cachedGet(url, ttlSec)
    if text = invalid then return invalid
    return ParseJson(text)
end function

function urlEncode(s as string) as string
    u = CreateObject("roUrlTransfer")
    return u.Escape(s)
end function

' ---------------- Modelos ----------------
function isHttp(u as dynamic) as boolean
    return u <> invalid and (type(u) = "roString" or type(u) = "String") and Left(u, 4) = "http"
end function

function pickImage(images as dynamic, types as object, sizes as object) as dynamic
    if images = invalid then return invalid
    for each t in types
        bySize = images[t]
        if bySize <> invalid then
            for each s in sizes
                if isHttp(bySize[s]) then return bySize[s]
            end for
            for each k in bySize
                if isHttp(bySize[k]) then return bySize[k]
            end for
        end if
    end for
    return invalid
end function

function anyImage(images as dynamic) as dynamic
    if images = invalid then return invalid
    for each t in images
        v = images[t]
        if type(v) = "roAssociativeArray" then
            for each s in v
                if isHttp(v[s]) then return v[s]
            end for
        end if
    end for
    return invalid
end function

function imageSet(images as dynamic) as object
    card = pickImage(images, ["wsr", "wss", "lsr", "lss", "pnr", "sqr", "sqs", "cvr"], ["lg", "md", "xl", "sm", "xs"])
    if card = invalid then card = anyImage(images)
    backdrop = pickImage(images, ["pnr", "wsr", "lsr", "wss", "lss"], ["xl", "lg", "md", "sm"])
    if backdrop = invalid then backdrop = card
    square = pickImage(images, ["sqr", "sqs", "cvr"], ["lg", "xl", "md", "sm"])
    if square = invalid then square = card
    return {card: card, backdrop: backdrop, square: square}
end function

' Convierte un elemento del catálogo en un objeto simple para la interfaz.
function normalizeMedia(o as dynamic, lang as string) as dynamic
    if o = invalid then return invalid
    natural = o.naturalKey
    if natural = invalid then natural = ""
    lank = o.languageAgnosticNaturalKey
    if lank = invalid then lank = ""
    if natural = "" and lank = "" then return invalid
    files = []
    hasVideo = false
    reH = CreateObject("roRegex", "(\d{3,4})[pP]", "")
    if o.files <> invalid then
        for each f in o.files
            url = f.progressiveDownloadURL
            if url = invalid then url = f.url
            mime = f.mimetype
            if mime = invalid then mime = ""
            if url <> invalid and Instr(1, mime, "3gp") = 0 then
                label = f.label
                if label = invalid then label = ""
                h = 0
                mm = reH.Match(label)
                if mm.count() > 1 then
                    h = mm[1].toInt()
                else if f.frameHeight <> invalid then
                    h = Int(f.frameHeight)
                end if
                subUrl = invalid
                if f.subtitles <> invalid and f.subtitles.url <> invalid then subUrl = f.subtitles.url
                isVid = Left(mime, 5) = "video" or LCase(Right(url, 4)) = ".mp4" or LCase(Right(url, 5)) = ".m3u8"
                if isVid then hasVideo = true
                files.push({url: url, height: h, mime: mime, subtitles: subUrl, video: isVid})
            end if
        end for
    end if
    typ = o.type
    if typ = invalid then typ = ""
    duration = 0
    if o.duration <> invalid then duration = Int(o.duration)
    durText = ""
    if duration > 0 then
        durText = fmtTime(duration)
    else if o.durationFormattedMinSec <> invalid then
        durText = o.durationFormattedMinSec
    end if
    pub = ""
    if o.firstPublished <> invalid then pub = Left(o.firstPublished, 10)
    key = lank
    if key = "" then key = natural
    img = imageSet(o.images)
    title = o.title
    if title = invalid then title = ""
    desc = o.description
    if desc = invalid then desc = ""
    return {
        kind: "media", key: key, naturalKey: natural, lang: lang, type: typ,
        title: title, description: desc, duration: duration, durationText: durText, published: pub,
        card: img.card, backdrop: img.backdrop, square: img.square,
        files: files, isAudio: (LCase(typ) = "audio") or (files.count() > 0 and not hasVideo)
    }
end function

function parseCategory(o as dynamic, lang as string) as object
    c = {key: "", name: "", subcategories: [], media: [], image: invalid}
    if o = invalid then return c
    if o.key <> invalid then c.key = o.key
    if o.name <> invalid then c.name = o.name
    c.image = imageSet(o.images).card
    if o.subcategories <> invalid then
        for each s in o.subcategories
            if s.key <> invalid then c.subcategories.push(parseCategory(s, lang))
        end for
    end if
    if o.media <> invalid then
        for each mo in o.media
            mi = normalizeMedia(mo, lang)
            if mi <> invalid then c.media.push(mi)
        end for
    end if
    return c
end function

function categoryImage(c as object) as dynamic
    if c.image <> invalid then return c.image
    best = invalid
    for each mi in c.media
        if mi.card <> invalid and (best = invalid or mi.published > best.published) then best = mi
    end for
    if best <> invalid then return best.card
    for each s in c.subcategories
        i = categoryImage(s)
        if i <> invalid then return i
    end for
    return invalid
end function

function uniqueMedia(list as object, limit = 100000 as integer) as object
    seen = {}
    out = []
    for each mi in list
        if mi <> invalid and not seen.DoesExist(mi.key) then
            seen[mi.key] = true
            out.push(mi)
            if out.count() >= limit then exit for
        end if
    end for
    return out
end function

function latestMedia(c as object, limit as integer) as object
    all = []
    all.append(c.media)
    for each s in c.subcategories
        all.append(s.media)
    end for
    all = uniqueMedia(all)
    all.SortBy("published", "r")
    out = []
    for i = 0 to all.count() - 1
        if i >= limit then exit for
        out.push(all[i])
    end for
    return out
end function

function category(lang as string, key as string) as dynamic
    k = apiConst()
    j = getJson(k.MEDIATOR + "/categories/" + lang + "/" + urlEncode(key) + "?detailed=1&clientType=www")
    if j = invalid or j.category = invalid then return invalid
    return parseCategory(j.category, lang)
end function

function catCard(c as object, viewAll = false as boolean) as object
    return {kind: "category", key: c.key, name: c.name, image: categoryImage(c), viewAll: viewAll}
end function

function tile(o as object) as object
    t = {kind: "tile", subtitle: "", icon: invalid, image: invalid, text: invalid, color: "#2A3446", compact: false}
    t.append(o)
    return t
end function

' ---------------- Elementos sueltos ----------------
function mediaItem(lang as string, key as string) as dynamic
    if Left(key, 6) = "bible-" then return bibleItem(lang, key)
    k = apiConst()
    j = getJson(k.MEDIATOR + "/media-items/" + lang + "/" + urlEncode(key) + "?clientType=www", 3600)
    if j = invalid or j.media = invalid or j.media.count() = 0 then return invalid
    return normalizeMedia(j.media[0], lang)
end function

' ---------------- Inicio ----------------
function rowItems(lang as string, key as string, latest as boolean) as object
    k = apiConst()
    c = category(lang, key)
    if c = invalid then return {name: "", items: [], viewAll: invalid}
    items = []
    if c.media.count() > 0 then
        items = uniqueMedia(c.media, k.MAX_ROW)
    else if latest then
        items = latestMedia(c, k.MAX_ROW)
    end if
    if items.count() = 0 then
        for each s in c.subcategories
            items.push(catCard(s))
        end for
    end if
    viewAll = invalid
    if c.subcategories.count() > 0 or c.media.count() > k.MAX_ROW then viewAll = catCard(c, true)
    return {name: c.name, items: items, viewAll: viewAll}
end function

function mediaOf(lang as string, keys as object) as object
    all = []
    for each key in keys
        c = category(lang, key)
        if c <> invalid then
            if c.media.count() > 0 then
                all.append(c.media)
            else
                for each s in c.subcategories
                    all.append(s.media)
                end for
            end if
        end if
    end for
    return uniqueMedia(all, apiConst().MAX_ROW)
end function

function homeRows(lang as string) as object
    vod = category(lang, "VideoOnDemand")
    rows = []
    if vod <> invalid then
        for each s in vod.subcategories
            rows.push({id: s.key, title: s.name, latest: true})
        end for
    end if
    rows.push({id: "Audio", title: tx("audio"), latest: false})
    return rows
end function

function shortcuts(lang as string, gnImage as dynamic) as object
    gn = tile({id: "goodnews", title: tx("gn_title"), subtitle: tx("gn_subtitle"), image: gnImage, icon: "tiles/tile_goodnews.png", action: {open: "goodnews", title: tx("gn_title")}})
    if gnImage <> invalid then gn.icon = invalid
    return [
        gn
        tile({id: "live", title: tx("live"), subtitle: tx("live_subtitle"), icon: "tiles/tile_live.png", action: {live: true}})
        tile({id: "meeting", title: tx("meeting"), subtitle: tx("meeting_subtitle"), icon: "tiles/tile_meeting.png", action: {open: "meeting", title: tx("meeting")}})
        tile({id: "favorites", title: tx("favorites"), subtitle: tx("favorites_subtitle"), icon: "tiles/tile_favorites.png", action: {open: "favorites", title: tx("favorites")}})
        tile({id: "categories", title: tx("categories"), icon: "tiles/tile_categories.png", action: {open: "categories", title: tx("categories")}})
        tile({id: "bible", title: tx("bible_audio"), icon: "tiles/tile_bible_audio.png", action: {open: "bible", title: tx("bible_audio")}})
        tile({id: "study", title: tx("study_bible"), icon: "tiles/tile_bible_study.png", action: {open: "study", title: tx("study_bible")}})
        tile({id: "jworg", title: tx("jworg"), subtitle: tx("jworg_subtitle"), icon: "tiles/tile_jworg.png", action: {qr: "https://www.jw.org/"}})
    ]
end function

' ---------------- Pantallas ----------------
function categoryScreen(lang as string, key as string) as object
    c = category(lang, key)
    if c = invalid then return {title: "", rows: [], message: tx("error_loading")}
    rows = []
    if c.subcategories.count() = 0 then
        rows.push({id: "grid", title: c.name, grid: true, items: uniqueMedia(c.media)})
        return {title: c.name, rows: rows}
    end if
    if c.media.count() > 0 then rows.push({id: "_own", title: c.name, items: uniqueMedia(c.media)})
    for each s in c.subcategories
        if s.media.count() > 0 then
            rows.push({id: s.key, title: s.name, items: uniqueMedia(s.media), viewAll: catCard(s, true)})
        else
            r = rowItems(lang, s.key, false)
            if r.items.count() > 0 then rows.push({id: s.key, title: s.name, items: r.items, viewAll: r.viewAll})
        end if
    end for
    return {title: c.name, rows: rows}
end function

function categoryCards(lang as string) as object
    out = []
    vod = category(lang, "VideoOnDemand")
    if vod <> invalid then
        for each s in vod.subcategories
            out.push(catCard(s))
        end for
    end if
    au = category(lang, "Audio")
    if au <> invalid then out.push(catCard(au))
    return out
end function

function screenData(lang as string, route as string) as object
    parts = route.Split("/")
    p0 = parts[0]
    if p0 = "categories" then
        return {title: tx("categories"), rows: [{id: "cats", title: tx("categories"), grid: true, items: categoryCards(lang)}]}
    else if p0 = "category" then
        return categoryScreen(lang, Mid(route, 10))
    else if p0 = "bible" then
        return bibleScreen(lang, parts)
    else if p0 = "study" then
        return studyScreen(lang, parts)
    else if p0 = "goodnews" then
        return goodNews(lang)
    else if p0 = "meeting" then
        return meetingScreen(lang)
    end if
    return {title: "", rows: [], message: tx("error_loading")}
end function

' ---------------- Biblia en audio ----------------
function pubLinks(params as object) as dynamic
    k = apiConst()
    q = "output=json&alllangs=0"
    for each p in params
        q = q + "&" + p + "=" + urlEncode(params[p])
    end for
    text = cachedGet(k.PUBMEDIA + "?" + q, 6 * 3600)
    if text = invalid then return invalid
    if Left(text.Trim(), 1) = "[" then return invalid
    return ParseJson(text)
end function

function pubFiles(json as dynamic, format as string) as object
    out = []
    if json = invalid or json.files = invalid then return out
    for each lg in json.files
        byFmt = json.files[lg]
        if byFmt <> invalid and byFmt[format] <> invalid then out.append(byFmt[format])
    end for
    return out
end function

function cleanHtml(s as dynamic) as string
    if s = invalid then return ""
    re = CreateObject("roRegex", "<[^>]*>", "")
    return re.ReplaceAll(s, "").Replace("&nbsp;", " ").Replace("&amp;", "&").Trim()
end function

function markerDuration(f as object) as integer
    if f.duration <> invalid and f.duration > 0 then return Int(f.duration)
    if f.markers = invalid or f.markers.markers = invalid then return 0
    mk = f.markers.markers
    if mk.count() = 0 then return 0
    last = mk[mk.count() - 1]
    return hmsToSec(last.startTime) + hmsToSec(last.duration)
end function

function hmsToSec(s as dynamic) as integer
    if s = invalid then return 0
    p = s.Split(":")
    if p.count() <> 3 then return 0
    return p[0].toInt() * 3600 + p[1].toInt() * 60 + Int(Val(p[2]))
end function

' Capítulos de una edición ("nwt" actual, "bi12" anterior) agrupados por libro: {name, books: {"1": [items]}}
function bibleChapters(lang as string, pub as string) as dynamic
    json = pubLinks({pub: pub, langwritten: lang, fileformat: "MP3"})
    if json = invalid then return invalid
    edition = cleanHtml(json.pubName)
    books = {}
    names = {}
    for each f in pubFiles(json, "MP3")
        url = invalid
        if f.file <> invalid then url = f.file.url
        b = 0 : c = 0
        if f.booknum <> invalid then b = Int(f.booknum)
        if f.track <> invalid then c = Int(f.track)
        if isHttp(url) and b >= 1 and b <= 66 and c >= 1 then
            title = cleanHtml(f.title)
            sp = title.Split(" - ")
            if sp.count() > 1 then names[b.toStr()] = sp[0].Trim()
            item = {
                kind: "media", key: "bible-" + pub + "-" + b.toStr() + "-" + c.toStr(), naturalKey: "bible-" + pub + "-" + lang + "-" + b.toStr() + "-" + c.toStr(),
                lang: lang, type: "audio", title: title.Replace(" - ", " · "), description: edition, duration: markerDuration(f),
                durationText: fmtTime(markerDuration(f)), published: "", card: invalid, backdrop: invalid, square: invalid,
                files: [{url: url, height: 0, mime: "audio/mpeg", subtitles: invalid, video: false}], isAudio: true, chapter: c
            }
            if books[b.toStr()] = invalid then books[b.toStr()] = []
            books[b.toStr()].push(item)
        end if
    end for
    if books.count() = 0 then return invalid
    for each bk in books
        books[bk].SortBy("chapter")
    end for
    return {name: edition, books: books, names: names}
end function

function bibleItem(lang as string, key as string) as dynamic
    ' bible-<pub>-<libro>-<capítulo>
    p = key.Split("-")
    if p.count() < 4 then return invalid
    data = bibleChapters(lang, p[1])
    if data = invalid then return invalid
    list = data.books[p[2]]
    if list = invalid then return invalid
    for each it in list
        if it.key = key then return it
    end for
    return invalid
end function

function bookNames(lang as string) as object
    all = readJson(bpRoot() + "data/bible_books.json")
    if all[lang] <> invalid then return all[lang]
    base = all[m.global.strings._ui]
    if base = invalid then base = all["E"]
    data = bibleChapters(lang, "nwt")
    if data = invalid then return base
    out = []
    for i = 1 to 66
        n = data.names[i.toStr()]
        if n = invalid then n = base[i - 1]
        out.push(n)
    end for
    return out
end function

function bibleScreen(lang as string, parts as object) as object
    hebrew = "#3F5F8F" : greek = "#3E7066" : older = "#7B5B3B" : accent = "#4A6DA7"
    if parts.count() = 1 then
        items = []
        i = 0
        for each pub in ["nwt", "bi12"]
            d = bibleChapters(lang, pub)
            if d <> invalid then
                re = CreateObject("roRegex", "(1[89]\d\d|20\d\d)", "")
                mm = re.Match(d.name)
                txt = d.name
                if mm.count() > 0 then txt = mm[0]
                subText = tx("edition_current")
                col = hebrew
                if i > 0 then
                    subText = tx("edition_previous")
                    col = older
                end if
                items.push(tile({id: "ed-" + pub, title: d.name, subtitle: subText, text: txt, color: col, action: {open: "bible/" + pub, title: d.name}}))
                i = i + 1
            end if
        end for
        if items.count() = 0 then return {title: tx("bible_audio"), rows: [], message: tx("not_available")}
        return {title: tx("bible_audio"), rows: [{id: "editions", title: tx("choose_edition"), grid: true, items: items}]}
    end if
    pub = parts[1]
    d = bibleChapters(lang, pub)
    if d = invalid then return {title: tx("bible_audio"), rows: [], message: tx("not_available")}
    names = bookNames(lang)
    if parts.count() = 2 then
        heb = [] : grk = []
        for b = 1 to 66
            list = d.books[b.toStr()]
            if list <> invalid then
                col = greek
                if b <= 39 then col = hebrew
                t = tile({id: "b" + b.toStr(), title: names[b - 1], subtitle: plural("chapters_count", list.count()), text: names[b - 1], color: col, compact: true, action: {open: "bible/" + pub + "/" + b.toStr(), title: names[b - 1]}})
                if b <= 39 then heb.push(t) else grk.push(t)
            end if
        end for
        rows = []
        if heb.count() > 0 then rows.push({id: "heb", title: tx("hebrew_scriptures"), grid: true, items: heb})
        if grk.count() > 0 then rows.push({id: "grk", title: tx("greek_scriptures"), grid: true, items: grk})
        return {title: d.name, rows: rows}
    end if
    book = parts[2].toInt()
    list = d.books[book.toStr()]
    if list = invalid then list = []
    col = greek
    if book <= 39 then col = hebrew
    items = [tile({id: "all", title: tx("play_whole_book"), subtitle: tx("play_whole_book"), text: "▶", color: accent, compact: true, action: {play: list, index: 0}})]
    for i = 0 to list.count() - 1
        items.push(tile({id: "c" + (i + 1).toStr(), title: tx("chapter_n", i + 1), subtitle: list[i].durationText, text: (i + 1).toStr(), color: col, compact: true, action: {play: list, index: i}}))
    end for
    return {title: names[book - 1], rows: [{id: "ch", title: names[book - 1], grid: true, items: items}]}
end function

' ---------------- Biblia de estudio ----------------
function studyScreen(lang as string, parts as object) as object
    study = readJson(bpRoot() + "data/study_bible_videos.json")
    names = bookNames(lang)
    byBook = {}
    for each e in study.videos
        k = e.b.toStr()
        if byBook[k] = invalid then byBook[k] = []
        byBook[k].push(e)
    end for
    isStudy = {}
    for each b in study.studyBooks
        isStudy[b.toStr()] = true
    end for
    if parts.count() = 1 then
        withNotes = [] : intros = []
        for b = 0 to 66
            list = byBook[b.toStr()]
            if list <> invalid then
                name = tx("bible_info")
                if b > 0 then name = names[b - 1]
                subText = plural("videos_count", list.count())
                col = "#3F5F8F"
                if b = 0 then col = "#5D4F80"
                if isStudy[b.toStr()] = true then
                    subText = "◆ " + subText
                    col = "#3E7066"
                end if
                t = tile({id: "s" + b.toStr(), title: name, subtitle: subText, text: name, color: col, compact: true, action: {open: "study/" + b.toStr(), title: name}})
                if isStudy[b.toStr()] = true then withNotes.push(t) else intros.push(t)
            end if
        end for
        return {title: tx("study_bible"), rows: [{id: "notes", title: tx("study_with_notes"), grid: true, items: withNotes}, {id: "intro", title: tx("study_intros"), grid: true, items: intros}]}
    end if
    book = parts[1].toInt()
    list = byBook[book.toStr()]
    if list = invalid then list = []
    byChapter = {}
    order = []
    for each e in list
        mi = mediaItem(lang, e.k)
        if mi <> invalid then
            ck = e.c.toStr()
            if byChapter[ck] = invalid then
                byChapter[ck] = []
                order.push(e.c)
            end if
            byChapter[ck].push(mi)
        end if
    end for
    order.Sort()
    rows = []
    for each c in order
        t = tx("chapter_n", c)
        if c = 0 then t = tx("introduction")
        rows.push({id: "c" + c.toStr(), title: t, items: byChapter[c.toStr()]})
    end for
    title = tx("bible_info")
    if book > 0 then title = names[book - 1]
    if rows.count() = 0 then return {title: title, rows: [], message: tx("not_available")}
    return {title: title, rows: rows}
end function

' ---------------- Las buenas noticias según Jesús ----------------
function episodeNumber(key as string) as integer
    re = CreateObject("roRegex", "pub-gnj_(\d+)_VIDEO", "")
    mm = re.Match(key)
    if mm.count() < 2 then return 0
    n = mm[1].toInt()
    if n >= 501 and n <= 899 then return n - 500
    return n
end function

function gnEpisodes(lang as string) as object
    k = apiConst()
    c = category(lang, k.GN_KEY)
    if c = invalid then return {name: tx("gn_title"), episodes: []}
    eps = []
    for each mi in uniqueMedia(c.media)
        n = episodeNumber(mi.key)
        if n >= 1 and n <= 499 and mi.key <> k.GN_TRAILER then
            mi.ep = n
            eps.push(mi)
        end if
    end for
    eps.SortBy("ep")
    return {name: c.name, episodes: eps}
end function

function gnHome(lang as string) as object
    k = apiConst()
    g = gnEpisodes(lang)
    tr0 = mediaItem(lang, k.GN_TRAILER)
    img = invalid
    if tr0 <> invalid then img = tr0.card
    return {name: g.name, episodes: g.episodes, image: img}
end function

function goodNews(lang as string) as object
    k = apiConst()
    g = gnEpisodes(lang)
    rows = [{id: "eps", title: tx("gn_episodes"), items: g.episodes}]
    ad = category(lang, k.GN_KEY_AD)
    adList = []
    if ad <> invalid then
        for each mi in ad.media
            mi.ep = episodeNumber(mi.key)
            adList.push(mi)
        end for
        adList.SortBy("ep")
    end if
    tad = mediaItem(lang, k.GN_TRAILER_AD)
    if tad <> invalid then adList.push(tad)
    if adList.count() > 0 then rows.push({id: "ad", title: tx("gn_ad"), items: adList})
    t = mediaItem(lang, k.GN_TRAILER)
    if t <> invalid then rows.push({id: "trailer", title: tx("gn_trailer"), items: [t]})
    return {title: g.name, rows: rows, episodes: g.episodes}
end function

' ---------------- En vivo ----------------
' Mismo canal que en la TV y el teléfono: el catálogo mezclado con una semilla del día.
function liveSchedule(lang as string) as dynamic
    vod = category(lang, "VideoOnDemand")
    if vod = invalid then return invalid
    adRe = CreateObject("roRegex", "audiodescrip|audio description|audiodescri|тифлокоммент", "i")
    pool = []
    seen = {}
    for each s in vod.subcategories
        if Instr(1, LCase(s.key), "audiodescription") = 0 then
            c = category(lang, s.key)
            if c <> invalid then
                for each mi in latestMedia(c, 100000)
                    if not mi.isAudio and not adRe.IsMatch(mi.title) and mi.duration >= 60 and mi.duration <= 7200 and mi.files.count() > 0 and not seen.DoesExist(mi.key) then
                        seen[mi.key] = true
                        pool.push(mi)
                    end if
                end for
            end if
        end if
    end for
    if pool.count() = 0 then return invalid
    pool.SortBy("key")
    dt = CreateObject("roDateTime")
    dt.ToLocalTime()
    nowS = dt.AsSeconds()
    y = dt.GetYear()
    ' día del año (1 = 1 de enero)
    mdays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if (y mod 4 = 0 and y mod 100 <> 0) or y mod 400 = 0 then mdays[1] = 29
    dayOfYear = dt.GetDayOfMonth()
    for mo = 1 to dt.GetMonth() - 1
        dayOfYear = dayOfYear + mdays[mo - 1]
    end for
    seed& = y * 1000 + dayOfYear
    ' barajado reproducible (generador congruencial, igual que en las otras versiones)
    for i = pool.count() - 1 to 1 step -1
        seed& = (seed& * 1664525& + 1013904223&) mod 4294967296&
        j = Int((seed& / 4294967296#) * (i + 1))
        tmp = pool[i] : pool[i] = pool[j] : pool[j] = tmp
    end for
    secOfDay = dt.GetHours() * 3600 + dt.GetMinutes() * 60 + dt.GetSeconds()
    total& = 0
    for each mi in pool
        total& = total& + mi.duration
    end for
    elapsed = secOfDay mod total&
    idx = 0
    while idx < pool.count() and elapsed >= pool[idx].duration
        elapsed = elapsed - pool[idx].duration
        idx = idx + 1
    end while
    if idx >= pool.count() then idx = pool.count() - 1
    queue = []
    n = pool.count()
    if n > 60 then n = 60
    for q = 0 to n - 1
        queue.push(pool[(idx + q) mod pool.count()])
    end for
    return {items: queue, index: 0, position: elapsed}
end function

' ---------------- Reuniones (preparadas cada semana en GitHub) ----------------
function meetingScreen(lang as string) as object
    k = apiConst()
    j = getJson(k.FEED + "/meetings/" + lang + ".json?d=" + todayNum().toStr(), 3 * 3600)
    if j = invalid or j.weeks = invalid then return {title: tx("meeting"), rows: [], message: tx("meeting_empty")}
    today = todayNum()
    rows = []
    for each w in j.weeks
        if w.sunday >= today then
            label = tx("this_week")
            if w.monday > today then label = tx("next_week")
            weekRows = []
            for each r in w.rows
                items = []
                for each raw in r.items
                    mi = normalizeMedia(raw, lang)
                    if mi <> invalid then items.push(mi)
                end for
                if r.pictures <> invalid then
                    urls = [] : caps = []
                    for each p in r.pictures
                        urls.push(p.url)
                        caps.push(p.caption)
                    end for
                    for i = 0 to r.pictures.count() - 1
                        p = r.pictures[i]
                        ttl = p.caption
                        if ttl = invalid or ttl = "" then ttl = tx("picture_n", i + 1)
                        items.push(tile({id: "img" + i.toStr(), title: ttl, subtitle: tx("picture_n", i + 1), image: p.thumb, action: {images: urls, captions: caps, index: i}}))
                    end for
                end if
                title = r.title
                if r.kind = "midweek" then title = tx("meeting_midweek", r.title)
                if r.kind = "weekend" then title = tx("meeting_weekend", r.title)
                if items.count() > 0 then weekRows.push({id: r.kind + w.monday.toStr(), title: title, items: items})
            end for
            if weekRows.count() > 0 then
                rows.push({id: "h" + w.monday.toStr(), title: label, header: true, items: []})
                rows.append(weekRows)
            end if
            if rows.count() >= 6 then exit for
        end if
    end for
    if rows.count() = 0 then return {title: tx("meeting"), rows: [], message: tx("meeting_empty")}
    return {title: tx("meeting"), rows: rows}
end function

' ---------------- Búsqueda ----------------
' Recorre el catálogo (temas y subcategorías) para buscar por palabra o fecha.
function catalogIndex(lang as string) as object
    file = "tmp:/index_" + lang + ".json"
    fs = CreateObject("roFileSystem")
    if fs.Exists(file) then
        st = fs.Stat(file)
        if st <> invalid and nowSec() - st.mtime.AsSeconds() < 3600 then
            j = ParseJson(ReadAsciiFile(file))
            if j <> invalid then return j
        end if
    end if
    all = []
    vod = category(lang, "VideoOnDemand")
    roots = []
    if vod <> invalid then
        for each s in vod.subcategories
            roots.push(s.key)
        end for
    end if
    roots.push("Audio")
    pending = roots
    for level = 1 to 3
        nextLevel = []
        for each key in pending
            c = category(lang, key)
            if c <> invalid then
                for each mi in c.media
                    all.push(compactMedia(mi, key))
                end for
                for each s in c.subcategories
                    if s.media.count() > 0 then
                        for each mi in s.media
                            all.push(compactMedia(mi, key))
                        end for
                    else
                        nextLevel.push(s.key)
                    end if
                end for
            end if
        end for
        pending = nextLevel
        if pending.count() = 0 then exit for
    end for
    all = uniqueMedia(all)
    WriteAsciiFile(file, FormatJson(all))
    return all
end function

function compactMedia(mi as object, topic as string) as object
    return {kind: "media", key: mi.key, naturalKey: mi.naturalKey, lang: mi.lang, type: mi.type, title: mi.title, description: Left(mi.description, 300), duration: mi.duration, durationText: mi.durationText, published: mi.published, card: mi.card, backdrop: mi.backdrop, square: mi.square, files: mi.files, isAudio: mi.isAudio, topic: topic}
end function

function searchToken() as string
    k = apiConst()
    text = cachedGet(k.TOKEN, 900)
    if text = invalid then return ""
    return text.Trim()
end function

' Fecha escrita en el buscador: "enero 2025", "enero de 2025", "2024", "2025年1月", "01/2025".
function dateInQuery(q as string) as dynamic
    re = CreateObject("roRegex", "(\d{4})\s*(?:年|년|[-./])\s*(\d{1,2})\s*(?:月|월)?|(\d{1,2})\s*[/.-]\s*(\d{4})", "")
    mm = re.Match(q)
    if mm.count() > 0 then
        y = 0 : mo = 0
        if mm.count() > 2 and mm[1] <> "" then
            y = mm[1].toInt() : mo = mm[2].toInt()
        else if mm.count() > 4 then
            y = mm[4].toInt() : mo = mm[3].toInt()
        end if
        if y >= 1900 and mo >= 1 and mo <= 12 then return {year: y, month: mo, monthWord: invalid, rest: q.Replace(mm[0], " ")}
    end if
    words = queryWords(q)
    yi = -1
    reY = CreateObject("roRegex", "^(19|20)\d\d$", "")
    for i = 0 to words.count() - 1
        if reY.IsMatch(words[i]) then
            yi = i
            exit for
        end if
    end for
    if yi < 0 then return invalid
    months = {}
    for each code in [m.global.strings._ui, "S", "E"]
        mj = readJson(bpRoot() + "data/months/" + code + ".json")
        if mj <> invalid then months.append(mj.match)
    end for
    mi = -1
    for i = 0 to words.count() - 1
        if i <> yi and months[words[i]] <> invalid then
            mi = i
            exit for
        end if
    end for
    used = {}
    used[yi.toStr()] = true
    month = 0
    mword = invalid
    if mi >= 0 then
        used[mi.toStr()] = true
        month = months[words[mi]]
        mword = words[mi]
        a = mi : b = yi
        if a > b then
            a = yi : b = mi
        end if
        for i = a + 1 to b - 1
            if Len(words[i]) <= 3 then used[i.toStr()] = true
        end for
    end if
    rest = ""
    for i = 0 to words.count() - 1
        if used[i.toStr()] = invalid then rest = rest + " " + words[i]
    end for
    return {year: words[yi].toInt(), month: month, monthWord: mword, rest: rest.Trim()}
end function

function searchAll(lang as string, query as string) as object
    k = apiConst()
    q = query.Trim()
    typed = dateInQuery(q)
    if typed <> invalid then q = typed.rest
    words = queryWords(q)
    if words.count() = 0 and typed = invalid then return {categories: [], results: [], total: 0}
    index = catalogIndex(lang)
    found = {}
    order = []
    for each mi in index
        if Left(mi.key, 6) <> "bible-" and matchesWords(mi.title + " " + mi.description, words) then
            if not found.DoesExist(mi.key) then
                found[mi.key] = mi
                order.push(mi)
            end if
        end if
    end for
    cats = []
    if words.count() > 0 then
        tok = searchToken()
        for each pg in [["videos", 0], ["videos", 24], ["audio", 0]]
            url = k.SEARCH + "/" + lang + "/" + pg[0] + "?q=" + urlEncode(q) + "&offset=" + pg[1].toStr()
            r = httpRequest(url, "GET", "", {Authorization: "Bearer " + tok})
            if r.code = 200 then
                body = ParseJson(r.body)
                hits = []
                collectHits(body, hits, {})
                for each h in hits
                    if Left(h.lank, 3) = "mc-" then
                        if typed = invalid and matchesWords(h.title, words) then cats.push({kind: "category", key: Mid(h.lank, 4), name: h.title, image: h.image})
                    else if not found.DoesExist(h.lank) and matchesWords(h.title, words) and order.count() < 400 then
                        mi = mediaItem(lang, h.lank)
                        if mi <> invalid then
                            found[h.lank] = mi
                            order.push(mi)
                        end if
                    end if
                end for
            end if
        end for
    end if
    results = []
    adRe = CreateObject("roRegex", "audiodescri|audio descri|тифлокоммент|audiodescrição", "i")
    wantAd = adRe.IsMatch(query)
    for each mi in order
        ok = true
        if typed <> invalid then
            named = false
            if typed.monthWord <> invalid then
                tk = queryWords(mi.title)
                for i = 0 to tk.count() - 1
                    if tk[i] = typed.monthWord then
                        for j = i + 1 to i + 2
                            if j < tk.count() and tk[j] = typed.year.toStr() then named = true
                        end for
                    end if
                end for
            end if
            inDate = Left(mi.published, 4) = typed.year.toStr()
            if typed.month > 0 then inDate = inDate and Mid(mi.published, 6, 2) = padLeft(typed.month, 2)
            ok = inDate or named
        end if
        if ok and not wantAd and adRe.IsMatch(mi.title) then ok = false
        if ok then results.push(mi)
    end for
    results.SortBy("published", "r")
    total = results.count()
    out = []
    for i = 0 to total - 1
        if i >= 200 then exit for
        out.push(results[i])
    end for
    return {categories: cats, results: out, total: total, typedYear: typedYear(typed), typedMonth: typedMonth(typed)}
end function

function typedYear(t as dynamic) as integer
    if t = invalid then return 0
    return t.year
end function

function typedMonth(t as dynamic) as integer
    if t = invalid then return 0
    return t.month
end function

sub collectHits(node as dynamic, out as object, seen as object)
    t = type(node)
    if t = "roArray" then
        for each n in node
            collectHits(n, out, seen)
        end for
        return
    end if
    if t <> "roAssociativeArray" then return
    lank = node.lank
    if lank = invalid then lank = node.languageAgnosticNaturalKey
    title = cleanHtml(node.title)
    if lank <> invalid and title <> "" and not seen.DoesExist(lank) then
        seen[lank] = true
        img = invalid
        if node.image <> invalid and isHttp(node.image.url) then img = node.image.url
        if img = invalid then img = imageSet(node.images).card
        out.push({lank: lank, title: title, image: img})
    end if
    for each k in node
        v = node[k]
        tv = type(v)
        if tv = "roArray" or tv = "roAssociativeArray" then collectHits(v, out, seen)
    end for
end sub

' ---------------- Idiomas ----------------
' Nombres de los idiomas en el idioma de los menús (si jw.org los tiene).
function localLanguageNames(ui as string) as object
    j = getJson(apiConst().MEDIATOR + "/languages/" + ui + "/all?clientType=www", 7 * 86400)
    out = {}
    if j <> invalid and j.languages <> invalid then
        for each l in j.languages
            out[l.code] = l.name
        end for
    end if
    return out
end function
