' Idioma del contenido, idioma de los menús y colores.

function allLanguages() as object
    if m.bpLangs <> invalid then return m.bpLangs
    ' [código, nombre en inglés, nombre propio, señas, derecha-a-izquierda, locale]
    m.bpLangs = readJson(bpRoot() + "data/languages.json")
    if m.bpLangs = invalid then m.bpLangs = []
    return m.bpLangs
end function

function languageInfo(code as string) as dynamic
    for each l in allLanguages()
        if l[0] = code then return l
    end for
    return invalid
end function

' Idioma de los menús para un idioma de contenido (el mismo si está traducido; si no, uno cercano; si no, inglés).
function uiFor(lang as string) as string
    override = regRead("prefs", "ui_lang", "")
    uiList = ["S", "E", "T", "U", "F", "X", "I", "O", "P", "K", "M", "H", "B", "G", "TK", "A", "IN", "TG", "VT", "J", "KO", "CHS", "CH", "SI", "HI", "SW", "Z", "N", "D", "FI"]
    for each u in uiList
        if override = u then return u
    end for
    for each u in uiList
        if lang = u then return u
    end for
    info = languageInfo(lang)
    if info = invalid then return "E"
    loc = info[5]
    if loc = "cmn_hans" then return "CHS"
    if Left(loc, 3) = "cmn" or Left(loc, 3) = "yue" then return "CH"
    if info[3] = 1 then
        name = LCase(info[1])
        hints = [
            ["argentin|bolivi|chile|colombi|costa ric|cuba|dominican|ecuador|salvador|guatemal|hondur|mexic|nicaragu|panam|paragua|peru|puerto ric|spanish|spain|urugua|venezuel", "S"]
            ["brazil|portug|angol|mozambi", "T"], ["french|quebec|ivor|congo|camero|senegal|haiti|burkina|benin|gabon|togo|madagas", "F"]
            ["german|austria|swiss", "X"], ["italian", "I"], ["russian", "U"], ["ukrain", "K"], ["japanese", "J"], ["korean", "KO"]
            ["chinese|taiwan|hong kong", "CH"], ["dutch|flemish", "O"], ["polish", "P"], ["romanian", "M"], ["hungarian", "H"], ["czech", "B"]
            ["greek", "G"], ["turkish", "TK"], ["indonesian", "IN"], ["filipino|philippine", "TG"], ["vietnam", "VT"], ["thai", "SI"]
            ["indian", "HI"], ["kenyan|tanzanian", "SW"], ["swedish", "Z"], ["norwegian", "N"], ["danish", "D"], ["finnish", "FI"]
            ["arab|egypt|jordan|leban|syria|iraq|saudi|moroc|tunisi|algeri|libya|sudan", "A"]
        ]
        for each h in hints
            re = CreateObject("roRegex", h[0], "i")
            if re.IsMatch(name) then return h[1]
        end for
        return "E"
    end if
    return "S"
    byLocale = {es: "S", en: "E", pt: "T", ru: "U", fr: "F", de: "X", it: "I", ja: "J", ko: "KO", nl: "O", pl: "P", uk: "K", ro: "M", hu: "H", cs: "B", el: "G", tr: "TK", ar: "A", id: "IN", tl: "TG", fil: "TG", vi: "VT", th: "SI", hi: "HI", sw: "SW", sv: "Z", no: "N", nb: "N", nn: "N", da: "D", fi: "FI"}
    base = loc.Split("_")[0]
    u = byLocale[base]
    if u = invalid then return "E"
    return u
end function

' Idioma inicial: el guardado o, la primera vez, el del Roku.
function contentLanguage() as string
    saved = regRead("prefs", "lang")
    if saved <> invalid and saved <> "" then return saved
    loc = LCase(Left(m.global.deviceLocale, 2))
    byLocale = {es: "S", en: "E", pt: "T", ru: "U", fr: "F", de: "X", it: "I"}
    if byLocale[loc] <> invalid then return byLocale[loc]
    return "S"
end function

' Carga los textos de los menús para el idioma del contenido.
sub loadStrings(lang as string)
    ui = uiFor(lang)
    s = readJson(bpRoot() + "data/i18n/" + ui + ".json")
    if s = invalid then s = readJson(bpRoot() + "data/i18n/E.json")
    s._ui = ui
    m.global.strings = s
    m.global.lang = lang
    m.bpStrings = s
end sub

' Colores: modo noche (predeterminado, estilo original) o modo día.
function themeColors(theme as string) as object
    if theme = "day" then
        return {bg: "0xF3F4F6FF", surface: "0xFFFFFFFF", card: "0xE3E6EBFF", text: "0x1C2028FF", muted: "0x5D6470FF", accent: "0x3E6BD6FF", menu: "0xFFFFFFF7", focus: "0x3E6BD6FF", focusText: "0xFFFFFFFF", scrim: "0xF3F4F6FF", day: true}
    end if
    return {bg: "0x0E1116FF", surface: "0x161A21FF", card: "0x1B2029FF", text: "0xFFFFFFFF", muted: "0xB3BAC5FF", accent: "0x5B8DEFFF", menu: "0x0E1116F7", focus: "0xFFFFFFFF", focusText: "0x0E1116FF", scrim: "0x0E1116FF", day: false}
end function

sub loadTheme()
    m.global.colors = themeColors(regRead("prefs", "theme", "night"))
end sub

function webLocale(lang as string) as string
    info = languageInfo(lang)
    if info = invalid then return "es"
    return info[5].Replace("_", "-")
end function
