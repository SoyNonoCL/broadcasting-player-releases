' Lo que se guarda en el Roku: preferencias, progreso de los videos y "Mis favoritos".
' El registro de un canal de Roku tiene unos 16 KB, así que se guarda lo justo.

function prefGet(key as string, def as dynamic) as dynamic
    return regRead("prefs", key, def)
end function

sub prefSet(key as string, value as string)
    regWrite("prefs", key, value)
end sub

' ---------------- Progreso ("Continuar viendo") ----------------
function progressAll() as object
    return regJson("progress", "list", [])
end function

function progressGet(mi as object) as dynamic
    for each p in progressAll()
        if p.k = mi.key and p.l = mi.lang then return p
    end for
    return invalid
end function

sub progressSave(mi as object, posSec as integer, dur as integer)
    list = progressAll()
    out = []
    if posSec > 15 and posSec < dur - 30 then
        out.push({k: mi.key, l: mi.lang, t: Left(mi.title, 80), i: mi.card, p: posSec, d: dur, a: mi.isAudio, s: nowSec()})
    end if
    for each p in list
        if not (p.k = mi.key and p.l = mi.lang) and out.count() < 18 then out.push(p)
    end for
    regWriteJson("progress", "list", out)
end sub

' ---------------- Mis favoritos ----------------
' Mismo formato que en Android y Windows (para sincronizar por Google Drive):
' clave → {type, lang, media|url..., added, removed}. Aquí se guarda una versión compacta.
function favAll() as object
    return regJson("fav", "items", {})
end function

sub favStore(all as object)
    ' límite de tamaño: se descartan los quitados más antiguos y, si hace falta, los favoritos más antiguos
    text = FormatJson(all)
    if Len(text) > 9000 then
        list = []
        for each k in all
            e = all[k]
            e._k = k
            e._t = e.added
            if e.removed > e._t then e._t = e.removed
            list.push(e)
        end for
        list.SortBy("_t", "r")
        all = {}
        for each e in list
            k = e._k
            e.Delete("_k") : e.Delete("_t")
            all[k] = e
            if Len(FormatJson(all)) > 8500 then
                all.Delete(k)
                exit for
            end if
        end for
        text = FormatJson(all)
    end if
    regWrite("fav", "items", text)
    regWrite("fav", "changed", nowSec().toStr())
end sub

function favKeyOf(item as dynamic) as dynamic
    if item = invalid then return invalid
    if item.kind = "media" then return "m:" + item.lang + "|" + item.key
    if item.kind = "image" then return "i:" + item.url
    return invalid
end function

' Lo que se marca al pulsar ✱ en una tarjeta (o invalid si no se puede marcar).
function favTarget(item as dynamic) as dynamic
    if item = invalid then return invalid
    if item.kind = "media" or item.kind = "image" then return item
    if item.kind = "tile" and item.action <> invalid then
        a = item.action
        if a.play <> invalid then return a.play[a.index]
        if a.images <> invalid then
            cap = ""
            if a.captions <> invalid and a.captions[a.index] <> invalid then cap = a.captions[a.index]
            return {kind: "image", url: a.images[a.index], caption: cap, title: item.subtitle}
        end if
    end if
    return invalid
end function

function favIsOn(item as dynamic) as boolean
    k = favKeyOf(favTarget(item))
    if k = invalid then return false
    e = favAll()[k]
    return e <> invalid and e.added > e.removed
end function

' Media en formato compacto (el mismo que entienden Android y Windows; sin archivos: se buscan al reproducir).
function favMediaJson(mi as object) as object
    img = {}
    if mi.card <> invalid then img.wsr = {lg: mi.card}
    if mi.square <> invalid and mi.square <> mi.card then img.sqr = {lg: mi.square}
    return {naturalKey: mi.naturalKey, languageAgnosticNaturalKey: mi.key, type: mi.type, title: Left(mi.title, 100), duration: mi.duration, firstPublished: mi.published, images: img, files: []}
end function

function favToggle(item as dynamic) as boolean
    target = favTarget(item)
    k = favKeyOf(target)
    if k = invalid then return false
    all = favAll()
    e = all[k]
    now = nowSec() * 1000&
    if e <> invalid and e.added > e.removed then
        e.removed = now
        all[k] = e
        favStore(all)
        return false
    end if
    if target.kind = "media" then
        all[k] = {type: "media", lang: target.lang, media: favMediaJson(target), added: now, removed: 0}
    else
        all[k] = {type: "image", url: target.url, caption: Left(target.caption, 120), title: Left(target.title, 60), added: now, removed: 0}
    end if
    favStore(all)
    return true
end function

' Favoritos vigentes, del más reciente al más antiguo.
function favList() as object
    all = favAll()
    list = []
    for each k in all
        e = all[k]
        if e.added > e.removed then list.push(e)
    end for
    list.SortBy("added", "r")
    return list
end function
