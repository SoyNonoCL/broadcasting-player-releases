sub init()
  m.top.functionName = "work"
end sub

sub work()
  r = m.top.request
  lang = r.lang
  t = r.type
  out = {ok: true, type: t, id: r.id}
  if t = "homeRows" then
    out.rows = homeRows(lang)
  else if t = "row" then
    out.row = rowItems(lang, r.key, r.latest = true)
  else if t = "featured" then
    out.items = mediaOf(lang, ["FeaturedLibraryLanding", "StudioFeatured"])
  else if t = "latest" then
    out.items = mediaOf(lang, ["LatestVideos"])
  else if t = "gnHome" then
    out.gn = gnHome(lang)
    out.shortcuts = shortcuts(lang, out.gn.image)
  else if t = "screen" then
    out.screen = screenData(lang, r.route)
  else if t = "live" then
    out.live = liveSchedule(lang)
  else if t = "search" then
    out.search = searchAll(lang, r.q)
  else if t = "media" then
    list = []
    for each k in r.keys
      mi = mediaItem(lang, k)
      if mi <> invalid then list.push(mi)
    end for
    out.items = list
  else if t = "langNames" then
    out.names = localLanguageNames(r.ui)
  else if t = "langIndex" then
    names = localLanguageNames(r.ui)
    list = []
    for each l in allLanguages()
      loc = names[l[0]]
      if loc = invalid or loc = "" then loc = l[1]
      loc = loc.Replace("&nbsp;", " ").Replace("&amp;", "&")
      label = loc
      vern = l[2].Replace("&nbsp;", " ").Replace("&amp;", "&")
      if LCase(vern) <> LCase(loc) then label = loc + "  —  " + vern
      list.push({c: l[0], label: label, sort: normText(loc), n: " " + normText(loc + " " + l[1] + " " + l[2]) + " " + LCase(l[0]), sign: l[3] = 1})
    end for
    list.SortBy("sort")
    out.list = list
  else if t = "driveStart" then
    out.code = driveStartDeviceFlow()
  else if t = "driveWait" then
    out.connected = driveWaitForAuthorization(r.code)
    if out.connected then out.sync = driveSync()
  else if t = "driveSync" then
    out.sync = driveSync()
  else if t = "version" then
    out.version = getJson(apiConst().REL + "/version.json?t=" + nowSec().toStr(), 0)
  end if
  m.top.response = out
end sub
