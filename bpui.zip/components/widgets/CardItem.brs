sub init()
  m.bg = m.top.findNode("bg")
  m.img = m.top.findNode("img")
  m.txt = m.top.findNode("txt")
  m.title = m.top.findNode("title")
  m.sub = m.top.findNode("sub")
  m.prog = m.top.findNode("prog")
  m.progBg = m.top.findNode("progBg")
  m.heart = m.top.findNode("heart")
  c = m.global.colors
  m.title.color = c.text
  m.sub.color = c.muted
  m.bg.blendColor = c.card
  m.prog.color = c.accent
end sub

sub layout()
  w = m.top.width : h = m.top.height
  if w = 0 or h = 0 then return
  ih = Int(w * 9 / 16)
  if ih > h - 56 then ih = h - 56
  m.ih = ih
  m.bg.width = w : m.bg.height = ih
  m.img.width = w : m.img.height = ih
  m.txt.width = w - 24 : m.txt.height = ih : m.txt.translation = [12, 0]
  m.title.width = w : m.title.translation = [0, ih + 10]
  m.sub.width = w : m.sub.translation = [0, ih + 44]
  m.progBg.width = w : m.progBg.translation = [0, ih - 6]
  m.prog.translation = [0, ih - 6]
  m.heart.translation = [w - 46, 10]
  onContent()
end sub

sub onContent()
  c = m.top.itemContent
  if c = invalid or m.ih = invalid then return
  w = m.top.width
  m.title.text = c.title
  m.sub.text = c.sub
  m.sub.visible = c.sub <> ""
  m.img.uri = ""
  m.txt.text = ""
  m.bg.blendColor = m.global.colors.card
  if c.img <> "" then
    m.img.uri = c.img
  else if c.icon <> "" then
    m.img.uri = "pkg:/images/" + c.icon
  else if c.txt <> "" then
    m.bg.blendColor = c.col
    m.txt.text = c.txt
    if Len(c.txt) <= 3 then
      m.txt.font = "font:LargeBoldSystemFont"
      m.txt.font.size = Int(m.ih * 0.42)
    else
      m.txt.font = "font:MediumBoldSystemFont"
      m.txt.font.size = 30
    end if
  end if
  p = c.prog
  m.progBg.visible = p > 0
  m.prog.visible = p > 0
  m.prog.width = Int(w * p)
  m.heart.visible = c.fav
end sub

sub onFocus()
  f = m.top.focusPercent
  if not m.top.rowListHasFocus then f = 0
  if f > 0.5 then
    m.title.color = m.global.colors.text
  else
    m.title.color = m.global.colors.muted
  end if
end sub
