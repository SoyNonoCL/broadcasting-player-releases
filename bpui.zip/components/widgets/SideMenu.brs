sub init()
  c = m.global.colors
  m.bg = m.top.findNode("bg")
  m.bg.color = c.menu
  m.list = m.top.findNode("list")
  lang = m.global.lang
  info = languageInfo(lang)
  langName = lang
  if info <> invalid then langName = info[2]
  m.entries = [
    {id: "home", icon: "home", label: tx("nav_home")}
    {id: "search", icon: "search", label: tx("search")}
    {id: "favorites", icon: "favorite", label: tx("favorites")}
    {id: "categories", icon: "explore", label: tx("categories")}
    {id: "language", icon: "language", label: tx("language_short") + " · " + langName}
    {id: "settings", icon: "settings", label: tx("settings")}
  ]
  m.rows = []
  y = 0
  for each e in m.entries
    g = CreateObject("roSGNode", "Group")
    g.translation = [16, y]
    hl = CreateObject("roSGNode", "Poster")
    hl.uri = "pkg:/images/pill.9.png"
    hl.width = 76 : hl.height = 76
    hl.blendColor = c.focus
    hl.visible = false
    ic = CreateObject("roSGNode", "Poster")
    ic.uri = "pkg:/images/icons/" + e.icon + ".png"
    ic.width = 40 : ic.height = 40
    ic.translation = [18, 18]
    ic.blendColor = c.muted
    lb = CreateObject("roSGNode", "Label")
    lb.text = e.label
    lb.translation = [84, 0]
    lb.height = 76
    lb.vertAlign = "center"
    lb.font = "font:SmallBoldSystemFont"
    lb.color = c.text
    lb.visible = false
    g.appendChild(hl) : g.appendChild(ic) : g.appendChild(lb)
    m.list.appendChild(g)
    m.rows.push({hl: hl, ic: ic, lb: lb})
    y = y + 92
  end for
  m.list.translation = [0, (1080 - y) / 2]
  m.index = 0
  m.rows[0].ic.blendColor = c.accent
  onExpanded()
end sub

sub onExpanded()
  c = m.global.colors
  open = m.top.expanded
  if open then m.bg.width = 440 else m.bg.width = 108
  m.bg.opacity = 1
  if not open then m.bg.color = "0x00000000" else m.bg.color = c.menu
  for i = 0 to m.rows.count() - 1
    r = m.rows[i]
    r.lb.visible = open
    focused = open and i = m.index
    r.hl.visible = focused
    if focused then
      r.hl.width = 400
      r.ic.blendColor = c.focusText
      r.lb.color = c.focusText
    else
      r.hl.width = 76
      r.lb.color = c.text
      if i = 0 and not open then r.ic.blendColor = c.accent else r.ic.blendColor = c.muted
    end if
  end for
end sub

function onKeyEvent(key as string, press as boolean) as boolean
  if not press or not m.top.expanded then return false
  if key = "up" then
    if m.index > 0 then m.index = m.index - 1
    onExpanded()
    return true
  else if key = "down" then
    if m.index < m.rows.count() - 1 then m.index = m.index + 1
    onExpanded()
    return true
  else if key = "OK" then
    m.top.selected = m.entries[m.index].id
    m.index = 0
    onExpanded()
    return true
  else if key = "right" or key = "back" then
    m.top.expanded = false
    m.index = 0
    onExpanded()
    m.top.closed = true
    return true
  end if
  return true
end function
