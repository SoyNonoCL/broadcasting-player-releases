' Broadcasting Player para Roku (app personal, no oficial).
' Recibe órdenes de "Mi TV" (teléfono o Windows) por la red: al abrir la app (args) o mientras está abierta (roInput).
sub main(args as dynamic)
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.SetMessagePort(port)
    g = screen.GetGlobalNode()
    g.AddFields({root: "pkg:/", ns: "", strings: {}, colors: {}, lang: "S", deviceLocale: ""})
    di = CreateObject("roDeviceInfo")
    g.deviceLocale = di.GetCurrentLocale()
    scene = screen.CreateScene("Launcher")
    screen.Show()
    input = CreateObject("roInput")
    input.SetMessagePort(port)
    if args <> invalid then scene.launchArgs = args
    while true
        msg = wait(0, port)
        t = type(msg)
        if t = "roSGScreenEvent" then
            if msg.IsScreenClosed() then return
        else if t = "roInputEvent" then
            if msg.IsInput() then scene.inputArgs = msg.GetInfo()
        end if
    end while
end sub
