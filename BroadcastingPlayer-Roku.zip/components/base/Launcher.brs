sub init()
  m.top.backgroundColor = "0x0E1116FF"
  m.top.backgroundUri = ""
  m.started = false
  m.pending = []
  m.boot = CreateObject("roSGNode", "BootTask")
  m.boot.observeField("result", "onBoot")
  m.boot.control = "RUN"
  m.timer = m.top.findNode("timeout")
  m.timer.observeField("fire", "useBundled")
  m.timer.control = "start"
end sub

function bundledVersion() as integer
  ai = CreateObject("roAppInfo")
  v = ai.GetValue("bp_ui_version")
  if v = invalid or v = "" then return 0
  return v.toInt()
end function

sub onBoot()
  r = m.boot.result
  if m.started then return
  if r.ok and r.roku <> invalid and r.roku.ui <> invalid and r.roku.ui.version <> invalid and r.roku.ui.version > bundledVersion() and r.roku.ui.url <> invalid then
    m.remoteVersion = r.roku.ui.version
    m.lib = CreateObject("roSGNode", "ComponentLibrary")
    m.lib.id = "BPUI"
    m.lib.observeField("loadStatus", "onLib")
    m.lib.uri = r.roku.ui.url
    m.timer.duration = 12
    m.timer.control = "start"
  else
    useBundled()
  end if
end sub

sub onLib()
  if m.started then return
  st = m.lib.loadStatus
  if st = "ready" then
    ui = CreateObject("roSGNode", "BPUI:MainUI")
    if ui <> invalid then
      m.global.root = "libpkg:/"
      m.global.ns = "BPUI:"
      start(ui, m.remoteVersion)
      return
    end if
    useBundled()
  else if st = "failed" then
    useBundled()
  end if
end sub

sub useBundled()
  if m.started then return
  m.global.root = "pkg:/"
  m.global.ns = ""
  start(CreateObject("roSGNode", "MainUI"), bundledVersion())
end sub

sub start(ui as object, version as integer)
  m.started = true
  m.timer.control = "stop"
  m.ui = ui
  ui.uiVersion = version
  m.top.appendChild(ui)
  ui.setFocus(true)
  ui.start = true
  for each a in m.pending
    ui.deepLink = a
  end for
  m.pending = []
end sub

sub onArgs(e as object)
  a = e.getData()
  if a = invalid or a.count() = 0 then return
  if m.ui <> invalid then m.ui.deepLink = a else m.pending.push(a)
end sub
