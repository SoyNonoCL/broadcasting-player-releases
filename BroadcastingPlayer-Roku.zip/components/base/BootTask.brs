sub init()
  m.top.functionName = "work"
end sub
sub work()
  port = CreateObject("roMessagePort")
  u = CreateObject("roUrlTransfer")
  u.SetMessagePort(port)
  dt = CreateObject("roDateTime")
  u.SetUrl("https://raw.githubusercontent.com/SoyNonoCL/broadcasting-player-releases/main/version.json?t=" + dt.AsSeconds().toStr())
  u.SetCertificatesFile("common:/certs/ca-bundle.crt")
  u.InitClientCertificates()
  out = {ok: false}
  if u.AsyncGetToString() then
    msg = wait(6000, port)
    if type(msg) = "roUrlEvent" and msg.GetResponseCode() = 200 then
      j = ParseJson(msg.GetString())
      if j <> invalid and j.roku <> invalid then
        out = {ok: true, roku: j.roku}
      end if
    else
      u.AsyncCancel()
    end if
  end if
  m.top.result = out
end sub
